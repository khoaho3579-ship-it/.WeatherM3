package com.example.weatherm3.core

enum class Sky { CLEAR, PARTLY, CLOUDY, FOG, DRIZZLE, RAIN, SNOW, STORM }

fun skyOf(code: Int): Sky = when (code) {
    0, 1 -> Sky.CLEAR
    2 -> Sky.PARTLY
    3 -> Sky.CLOUDY
    45, 48 -> Sky.FOG
    51, 53, 55, 56, 57 -> Sky.DRIZZLE
    61, 63, 65, 66, 67, 80, 81, 82 -> Sky.RAIN
    71, 73, 75, 77, 85, 86 -> Sky.SNOW
    95, 96, 99 -> Sky.STORM
    else -> Sky.PARTLY
}

fun describe(code: Int, l: L): String = when (code) {
    0 -> l.t("Trời quang", "Clear")
    1 -> l.t("Ít mây", "Mostly clear")
    2 -> l.t("Có mây rải rác", "Partly cloudy")
    3 -> l.t("Nhiều mây", "Cloudy")
    45, 48 -> l.t("Sương mù", "Fog")
    51, 53, 55 -> l.t("Mưa phùn", "Drizzle")
    56, 57 -> l.t("Mưa phùn lạnh", "Freezing drizzle")
    61 -> l.t("Mưa nhẹ", "Light rain")
    63 -> l.t("Mưa", "Rain")
    65 -> l.t("Mưa to", "Heavy rain")
    66, 67 -> l.t("Mưa băng", "Freezing rain")
    71, 73, 75, 77 -> l.t("Tuyết", "Snow")
    80, 81 -> l.t("Mưa rào", "Rain showers")
    82 -> l.t("Mưa rào lớn", "Violent showers")
    85, 86 -> l.t("Mưa tuyết", "Snow showers")
    95 -> l.t("Dông", "Thunderstorm")
    96, 99 -> l.t("Dông kèm mưa đá", "Thunderstorm with hail")
    else -> l.t("Thời tiết thay đổi", "Variable")
}

fun aqiLabel(aqi: Int, l: L): String = when {
    aqi <= 50 -> l.t("Tốt", "Good")
    aqi <= 100 -> l.t("Trung bình", "Moderate")
    aqi <= 150 -> l.t("Không tốt cho nhóm nhạy cảm", "Unhealthy for sensitive groups")
    aqi <= 200 -> l.t("Kém", "Unhealthy")
    aqi <= 300 -> l.t("Rất kém", "Very unhealthy")
    else -> l.t("Nguy hại", "Hazardous")
}

fun uvLabel(uv: Double, l: L): String = when {
    uv < 3 -> l.t("Thấp", "Low")
    uv < 6 -> l.t("Trung bình", "Moderate")
    uv < 8 -> l.t("Cao", "High")
    uv < 11 -> l.t("Rất cao", "Very high")
    else -> l.t("Cực cao", "Extreme")
}

fun compass(deg: Int, l: L): String {
    val vi = listOf("B", "ĐB", "Đ", "ĐN", "N", "TN", "T", "TB")
    val en = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
    val i = (((deg % 360) + 360) % 360 / 45.0 + 0.5).toInt() % 8
    return if (l.isVi) vi[i] else en[i]
}
