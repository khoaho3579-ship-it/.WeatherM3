package com.example.weatherm3.ui.theme

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Các thành phần kiểu "Expressive" được tự vẽ (không dùng API thử nghiệm của Material 3,
 * vì bản ổn định hiện tại chưa công khai chúng). Gom hết vào file này.
 */
@Composable
fun ExpressiveTheme(
    colorScheme: ColorScheme,
    motion: String,
    shapes: Shapes,
    typography: Typography,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = colorScheme,
        shapes = shapes,
        typography = typography,
        content = content
    )
}

private const val TWO_PI = (2.0 * PI).toFloat()

/** Vòng tải biến hình: đa giác lượn sóng vừa xoay vừa phồng/xẹp. */
@Composable
fun AppLoadingIndicator(modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "loading")
    val rot = tr.animateFloat(
        initialValue = 0f,
        targetValue = TWO_PI,
        animationSpec = infiniteRepeatable(tween(3200, easing = LinearEasing)),
        label = "rot"
    )
    val pulse = tr.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val color = MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        val r = minOf(size.width, size.height) / 2f
        val cx = size.width / 2f
        val cy = size.height / 2f
        val amp = 0.05f + 0.16f * pulse.value
        val base = r * (1f - amp) * 0.95f
        val path = Path()
        val steps = 180
        for (i in 0..steps) {
            val t = (i.toFloat() / steps) * TWO_PI
            val rad = base * (1f + amp * cos(7 * t + rot.value * 2f))
            val x = cx + rad * cos(t + rot.value)
            val y = cy + rad * sin(t + rot.value)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path, color)
    }
}

/** Thanh tiến trình dạng sóng (phần đã chạy lượn sóng, phần còn lại là đường thẳng). */
@Composable
fun AppWavyProgress(progress: Float, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "wave")
    val phase = tr.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing)),
        label = "phase"
    )
    val active = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.secondaryContainer
    Canvas(modifier.height(16.dp)) {
        val stroke = 4.dp.toPx()
        val amp = 3.dp.toPx()
        val wave = 22.dp.toPx()
        val midY = size.height / 2f
        val endX = size.width * progress.coerceIn(0f, 1f)
        drawLine(track, Offset(endX, midY), Offset(size.width, midY), strokeWidth = stroke, cap = StrokeCap.Round)
        val path = Path()
        var x = 0f
        var first = true
        while (x <= endX) {
            val y = midY + amp * sin((x / wave - phase.value) * TWO_PI)
            if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
            x += 3f
        }
        if (first) path.moveTo(0f, midY)
        drawPath(path, active, style = Stroke(stroke, cap = StrokeCap.Round))
    }
}

/** Hình lượn sóng (cookie / hoa / mặt trời) vẽ bằng công thức cực toạ độ. */
private fun wavyShape(n: Int, amp: Float, steps: Int) = GenericShape { size, _ ->
    val cx = size.width / 2f
    val cy = size.height / 2f
    val r = minOf(cx, cy) * (1f - amp)
    for (i in 0..steps) {
        val t = (i.toFloat() / steps) * TWO_PI
        val rad = r * (1f + amp * cos(n * t))
        val x = cx + rad * cos(t)
        val y = cy + rad * sin(t)
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

/** Khung hình icon: circle | cookie | flower | sunny | squircle. */
@Composable
fun iconShape(key: String): Shape = remember(key) {
    when (key) {
        "circle" -> CircleShape
        "flower" -> wavyShape(8, 0.12f, 240)
        "sunny" -> wavyShape(12, 0.09f, 360)
        "squircle" -> RoundedCornerShape(28.dp)
        else -> wavyShape(9, 0.06f, 270)
    }
}
