package com.example.weatherm3.core

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import java.util.Locale

/** Ngôn ngữ trong app: đổi tức thời (không cần khởi động lại) vì mọi chuỗi đi qua L.t(vi, en). */
@Immutable
data class L(val lang: String) {
    val isVi: Boolean get() = lang == "vi"
    val locale: Locale get() = Locale.forLanguageTag(lang)
    fun t(vi: String, en: String): String = if (isVi) vi else en
}

fun resolveLang(pref: String): String = when (pref) {
    "vi" -> "vi"
    "en" -> "en"
    else -> if (Locale.getDefault().language == "vi") "vi" else "en"
}

val LocalL = staticCompositionLocalOf { L("vi") }
