package com.example.weatherm3.core

import com.example.weatherm3.data.AppSettings
import com.example.weatherm3.data.WeatherBundle

/** Gợi ý thông minh theo quy tắc (không cần AI bên ngoài). */
object Insights {
    fun tips(b: WeatherBundle, s: AppSettings, l: L): List<String> {
        val out = mutableListOf<String>()
        val c = b.current
        val next12 = b.hourly.take(12)
        val maxRain = maxOf(next12.maxOfOrNull { it.rainChance } ?: 0, c.rainChance ?: 0)
        val storm = next12.any { it.code >= 95 } || c.code >= 95
        val aqi = b.air?.usAqi
        val uv = maxOf(c.uv ?: 0.0, b.daily.firstOrNull()?.uvMax ?: 0.0)

        if (storm) out += l.t("Có khả năng có dông: tránh ở ngoài trời trống trải, rút phích cắm thiết bị khi sét mạnh.",
            "Thunderstorms possible: avoid open areas outdoors.")
        if (maxRain >= 50) out += l.t("Khả năng mưa $maxRain%: nhớ mang ô hoặc áo mưa.",
            "Rain chance $maxRain%: bring an umbrella or raincoat.")
        when {
            c.feelsC >= 35 -> out += l.t("Trời rất nóng: uống nhiều nước, hạn chế ra nắng 11–15h.",
                "Very hot: drink water and avoid the sun from 11am to 3pm.")
            c.feelsC >= 30 -> out += l.t("Trời nóng: mặc đồ thoáng, nhẹ, màu sáng.", "Warm: wear light, breathable clothes.")
            c.feelsC <= 15 -> out += l.t("Trời lạnh: nên mặc áo khoác ấm.", "Cold: wear a warm jacket.")
            c.feelsC <= 20 -> out += l.t("Trời se lạnh: mang theo áo khoác mỏng.", "Cool: bring a light jacket.")
        }
        if (uv >= 6) out += l.t("Chỉ số UV ${uv.toInt()} (${uvLabel(uv, l)}): dùng kem chống nắng, đội mũ, đeo kính.",
            "UV index ${uv.toInt()} (${uvLabel(uv, l)}): use sunscreen, a hat and sunglasses.")
        if (aqi != null && aqi > 100) out += l.t("Không khí kém (AQI $aqi): hạn chế chạy bộ ngoài trời, nên đeo khẩu trang.",
            "Poor air quality (AQI $aqi): limit outdoor running and consider a mask.")
        if ((aqi == null || aqi <= 50) && maxRain < 30 && !storm && c.feelsC in 18.0..32.0)
            out += l.t("Thời tiết đẹp: rất hợp để chạy bộ hoặc đi dạo.", "Nice weather: great for a run or a walk.")
        if (c.windKmh >= 30) out += l.t("Gió khá mạnh (${c.windKmh.toInt()} km/h): cẩn thận khi đi xe máy.",
            "Strong wind (${c.windKmh.toInt()} km/h): take care on two wheels.")
        val rainSoon = b.hourly.take(48).any { it.rainChance >= 40 }
        if (!rainSoon && c.tempC >= 28) out += l.t("48 giờ tới ít mưa: nên tưới cây.", "Little rain in the next 48h: water your plants.")
        return out.take(5)
    }

    /** Cảnh báo ngắn cho thông báo (dựa trên 12 giờ tới + cảnh báo của nhà cung cấp). */
    fun alerts(b: WeatherBundle, l: L): List<String> {
        val out = mutableListOf<String>()
        out += b.alerts
        val next = b.hourly.take(12)
        if (next.any { it.code >= 95 }) out += l.t("Dông trong 12 giờ tới", "Thunderstorm within 12 hours")
        val rain = next.maxOfOrNull { it.rainChance } ?: 0
        if (rain >= 70) out += l.t("Khả năng mưa cao ($rain%)", "High chance of rain ($rain%)")
        val hot = maxOf(b.current.tempC, next.maxOfOrNull { it.tempC } ?: Double.MIN_VALUE)
        if (hot >= 37) out += l.t("Nắng nóng cực đoan ${hot.toInt()}°C", "Extreme heat ${hot.toInt()}°C")
        val cold = minOf(b.current.tempC, next.minOfOrNull { it.tempC } ?: Double.MAX_VALUE)
        if (cold <= 8) out += l.t("Rét đậm ${cold.toInt()}°C", "Severe cold ${cold.toInt()}°C")
        return out.distinct()
    }
}
