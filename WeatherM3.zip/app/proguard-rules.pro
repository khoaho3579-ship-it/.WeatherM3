# ---- Thuộc tính cần giữ cho R8 ----
-keepattributes *Annotation*, InnerClasses, EnclosingMethod, Signature, Exceptions, RuntimeVisibleAnnotations

# ---- kotlinx.serialization ----
-dontnote kotlinx.serialization.**
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.example.weatherm3.**$$serializer { *; }
-keepclassmembers class com.example.weatherm3.** { *** Companion; }
-keepclasseswithmembers class com.example.weatherm3.** { kotlinx.serialization.KSerializer serializer(...); }

# ---- Retrofit / OkHttp / Okio ----
-keepclassmembers,allowshrinking,allowobfuscation interface * { @retrofit2.http.* <methods>; }
-dontwarn org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement
-dontwarn javax.annotation.**
-dontwarn kotlin.Unit
-dontwarn retrofit2.KotlinExtensions
-dontwarn retrofit2.KotlinExtensions$*
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-keep,allowobfuscation,allowshrinking class kotlin.coroutines.Continuation

# ---- WebView (radar): cầu nối JS phải giữ nguyên tên phương thức ----
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
-keep class com.example.weatherm3.ui.RadarBridge { *; }

# ---- Glance / WorkManager (khởi tạo bằng reflection) ----
-keep class * extends androidx.work.ListenableWorker { <init>(...); }
-keep class * extends androidx.glance.appwidget.GlanceAppWidget { <init>(); }
-keep class * extends androidx.glance.appwidget.GlanceAppWidgetReceiver { <init>(); }

# ---- Material color utilities (tính bảng màu HCT) ----
-keep class com.google.android.material.color.utilities.** { *; }
