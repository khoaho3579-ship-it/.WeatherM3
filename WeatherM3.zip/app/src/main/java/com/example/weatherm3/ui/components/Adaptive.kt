@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.example.weatherm3.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Chữ lớn hơn mức này (đã gồm hệ số hệ thống × app) thì các bố cục chuyển sang dạng xếp dọc. */
const val BIG_FONT_SCALE = 1.3f

@Composable
fun isBigFont(): Boolean = LocalDensity.current.fontScale > BIG_FONT_SCALE

/** Đo bề rộng tối thiểu (dp) của một chuỗi mẫu với style cho trước, theo đúng cỡ chữ hiệu dụng. */
@Composable
fun rememberTextWidthDp(sample: String, style: TextStyle): Dp {
    val measurer = rememberTextMeasurer()
    val density = LocalDensity.current
    return remember(sample, style, density.density, density.fontScale) {
        val px = measurer.measure(sample, style = style, maxLines = 1, softWrap = false).size.width
        with(density) { px.toDp() }
    }
}

/**
 * Nhóm lựa chọn: ≤ 3 mục ngắn và đo thấy vừa → SegmentedButton, ngược lại → FilterChip tự xuống dòng.
 */
@Composable
fun AdaptiveChoice(
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val measurer = rememberTextMeasurer()
    val style = MaterialTheme.typography.labelLarge
    val density = LocalDensity.current
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val maxPx = with(density) { maxWidth.toPx() }
        val fits = remember(options, style, maxPx, density.fontScale) {
            if (options.size > 3) false else {
                val widest = options.maxOf { measurer.measure(it.second, style = style, maxLines = 1, softWrap = false).size.width }
                // mỗi nút: chữ + dấu check (~26dp) + đệm hai bên (~24dp)
                val extra = with(density) { 50.dp.toPx() }
                (widest + extra) * options.size <= maxPx
            }
        }
        if (fits) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                options.forEachIndexed { i, (k, label) ->
                    SegmentedButton(
                        selected = selected == k,
                        onClick = { onSelect(k) },
                        shape = SegmentedButtonDefaults.itemShape(i, options.size)
                    ) { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                }
            }
        } else {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                options.forEach { (k, label) ->
                    FilterChip(
                        selected = selected == k,
                        onClick = { onSelect(k) },
                        label = { Text(label, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                    )
                }
            }
        }
    }
}

/** Nhóm nút tự xuống dòng khi không đủ chỗ. */
@Composable
fun ActionRow(content: @Composable () -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) { content() }
}

@Composable
fun AppTonalButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    FilledTonalButton(onClick = onClick, enabled = enabled, modifier = modifier.heightIn(min = 48.dp)) {
        Text(text, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

@Composable
fun AppOutlinedButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    OutlinedButton(onClick = onClick, enabled = enabled, modifier = modifier.heightIn(min = 48.dp)) {
        Text(text, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

/**
 * Icon + chữ: icon căn theo DÒNG ĐẦU của chữ (không bị trôi khi chữ xuống 2-3 dòng).
 */
@Composable
fun IconText(
    icon: ImageVector,
    text: String,
    style: TextStyle,
    modifier: Modifier = Modifier,
    iconSize: Dp = 18.dp,
    iconTint: Color = MaterialTheme.colorScheme.primary,
    textColor: Color = Color.Unspecified,
    maxLines: Int = Int.MAX_VALUE,
    gap: Dp = 8.dp
) {
    val density = LocalDensity.current
    val lineDp = if (style.lineHeight.isSp) with(density) { style.lineHeight.toDp() } else iconSize
    Row(modifier, verticalAlignment = Alignment.Top) {
        androidx.compose.foundation.layout.Box(
            Modifier.heightIn(min = lineDp).width(iconSize),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, modifier = Modifier.size(iconSize), tint = iconTint) }
        androidx.compose.foundation.layout.Spacer(Modifier.width(gap))
        Text(
            text,
            Modifier.weight(1f, fill = false),
            style = style,
            color = textColor,
            maxLines = maxLines,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** Chữ một dòng tự thu nhỏ từng bước cho vừa chiều rộng (dùng cho số nhiệt độ lớn). */
@Composable
fun FitText(
    text: String,
    style: TextStyle,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    minScale: Float = 0.45f,
    textAlign: TextAlign? = null
) {
    val fs = LocalDensity.current.fontScale
    var scale by remember(text, style.fontSize, fs) { mutableFloatStateOf(1f) }
    Text(
        text,
        modifier,
        color = color,
        textAlign = textAlign,
        style = style.copy(
            fontSize = style.fontSize * scale,
            lineHeight = if (style.lineHeight.isSp) style.lineHeight * scale else style.lineHeight
        ),
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Clip,
        onTextLayout = { r ->
            if (r.hasVisualOverflow && scale > minScale) scale = (scale * 0.9f).coerceAtLeast(minScale)
        }
    )
}
