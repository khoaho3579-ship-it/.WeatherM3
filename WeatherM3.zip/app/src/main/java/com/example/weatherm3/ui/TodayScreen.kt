@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.example.weatherm3.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import com.example.weatherm3.ui.components.FitText
import com.example.weatherm3.ui.components.IconText
import com.example.weatherm3.ui.components.isBigFont
import com.example.weatherm3.ui.components.rememberTextWidthDp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.weatherm3.core.Fmt
import com.example.weatherm3.core.Insights
import com.example.weatherm3.core.L
import com.example.weatherm3.core.LocalL
import com.example.weatherm3.core.Sky
import com.example.weatherm3.core.aqiLabel
import com.example.weatherm3.core.compass
import com.example.weatherm3.core.describe
import com.example.weatherm3.core.skyOf
import com.example.weatherm3.core.uvLabel
import com.example.weatherm3.data.AppSettings
import com.example.weatherm3.data.DayW
import com.example.weatherm3.data.Place
import com.example.weatherm3.data.WeatherBundle
import com.example.weatherm3.ui.components.Appear
import com.example.weatherm3.ui.components.Card28
import com.example.weatherm3.ui.components.SectionTitle
import com.example.weatherm3.ui.components.WeatherBackdrop
import com.example.weatherm3.ui.components.WeatherGlyph
import com.example.weatherm3.ui.theme.AppLoadingIndicator
import com.example.weatherm3.ui.theme.LocalMotion
import com.example.weatherm3.ui.theme.iconShape
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private fun animOn(s: AppSettings, motion: String) = s.weatherAnim && !s.batterySaver && motion != "off"

@Composable
fun TodayScreen(vm: AppViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val l = LocalL.current
    val motion = LocalMotion.current
    val place = s.activePlace()
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    val bg = MaterialTheme.colorScheme.background
    val listState = rememberLazyListState()
    // Chỉ chạy hoạt ảnh vô hạn khi app đang RESUMED và header còn nhìn thấy.
    val resumed by LocalLifecycleOwner.current.lifecycle.currentStateAsState()
    val headerVisible by remember { derivedStateOf { listState.firstVisibleItemIndex == 0 } }
    val animateHeader = animOn(s, motion) && headerVisible && resumed.isAtLeast(Lifecycle.State.RESUMED)

    Scaffold(
        modifier = Modifier.nestedScroll(scroll.nestedScrollConnection),
        containerColor = bg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            LargeTopAppBar(
                title = { Text(place.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                scrollBehavior = scroll,
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = bg,
                    scrolledContainerColor = MaterialTheme.colorScheme.surfaceContainer
                ),
                actions = {
                    IconButton(onClick = { vm.refresh(true) }) {
                        Icon(Icons.Rounded.Refresh, contentDescription = l.t("Làm mới", "Refresh"))
                    }
                }
            )
        }
    ) { pad ->
        PullToRefreshBox(
            isRefreshing = ui.loading && ui.bundle != null,
            onRefresh = { vm.refresh(true) },
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
        ) {
            val b = ui.bundle
            // Tính 1 lần cho mỗi lần dữ liệu / cài đặt đổi (không tính trong lambda LazyColumn).
            val alerts = remember(b, l) { b?.let { Insights.alerts(it, l) } ?: emptyList() }
            val tips = remember(b, s, l) { b?.let { Insights.tips(it, s, l) } ?: emptyList() }
            val hours = remember(b) { b?.hourly?.take(24) ?: emptyList() }
            val metricRows = remember(s.cardOrder, s.hiddenCards) {
                val visible = s.orderedCards().filter { it !in s.hiddenCards }
                val rows = mutableListOf<List<String>>()
                var pending: String? = null
                for (k in visible) {
                    if (k == "sun") {
                        pending?.let { rows.add(listOf(it)) }
                        pending = null
                        rows.add(listOf(k))
                    } else {
                        val p = pending
                        if (p == null) pending = k else { rows.add(listOf(p, k)); pending = null }
                    }
                }
                pending?.let { rows.add(listOf(it)) }
                rows
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (b == null) {
                    item {
                        Box(Modifier.fillMaxWidth().height(320.dp), contentAlignment = Alignment.Center) {
                            if (ui.loading) {
                                AppLoadingIndicator(Modifier.size(72.dp))
                            } else {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Icon(Icons.Rounded.CloudOff, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
                                    Text(ui.error ?: l.t("Chưa có dữ liệu", "No data yet"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Button(onClick = { vm.refresh(true) }) { Text(l.t("Thử lại", "Retry")) }
                                }
                            }
                        }
                    }
                } else {
                    item(key = "header", contentType = "header") { Appear(0) { HeaderCard(b, s, l, place, animateHeader, motion) } }
                    if (ui.stale || ui.error != null) {
                        item(key = "stale", contentType = "banner") {
                            Appear(1) {
                                Box(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(MaterialTheme.shapes.large)
                                        .background(MaterialTheme.colorScheme.secondaryContainer)
                                        .padding(14.dp)
                                ) {
                                    IconText(
                                        Icons.Rounded.CloudOff,
                                        ui.error ?: l.t("Đang hiển thị dữ liệu đã lưu (ngoại tuyến).", "Showing saved data (offline)."),
                                        MaterialTheme.typography.bodyMedium,
                                        iconSize = 24.dp,
                                        iconTint = MaterialTheme.colorScheme.onSecondaryContainer,
                                        textColor = MaterialTheme.colorScheme.onSecondaryContainer,
                                        gap = 12.dp
                                    )
                                }
                            }
                        }
                    }
                    if (alerts.isNotEmpty()) {
                        item(key = "alerts", contentType = "alerts") {
                            Appear(1) {
                                Column(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(MaterialTheme.shapes.extraLarge)
                                        .background(MaterialTheme.colorScheme.errorContainer)
                                        .padding(18.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    IconText(
                                        Icons.Rounded.Warning,
                                        l.t("Cảnh báo thời tiết", "Weather alerts"),
                                        MaterialTheme.typography.titleMedium,
                                        iconSize = 24.dp,
                                        iconTint = MaterialTheme.colorScheme.onErrorContainer,
                                        textColor = MaterialTheme.colorScheme.onErrorContainer,
                                        gap = 12.dp
                                    )
                                    alerts.forEach {
                                        Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                                    }
                                }
                            }
                        }
                    }
                    if (tips.isNotEmpty()) {
                        item(key = "tips", contentType = "tips") {
                            Appear(2) {
                                Card28(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(l.t("Gợi ý hôm nay", "Today's tips"), style = MaterialTheme.typography.titleMedium)
                                        tips.forEach {
                                            IconText(Icons.Rounded.Check, it, MaterialTheme.typography.bodyMedium, gap = 10.dp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    item(key = "t-hourly", contentType = "title") { SectionTitle(l.t("Theo giờ", "Hourly")) }
                    item(key = "hourly", contentType = "hourly") {
                        Appear(3) {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(hours, key = { it.time }, contentType = { "hour" }) { h ->
                                    Column(
                                        Modifier
                                            .widthIn(min = 72.dp)
                                            .clip(MaterialTheme.shapes.extraLarge)
                                            .background(MaterialTheme.colorScheme.surfaceContainer)
                                            .padding(vertical = 14.dp, horizontal = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(Fmt.hourLabel(h.time, s, l), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, softWrap = false)
                                        WeatherGlyph(skyOf(h.code), h.isDay, false, Modifier.size(34.dp))
                                        Text(Fmt.temp(h.tempC, s), style = MaterialTheme.typography.titleMedium, maxLines = 1, softWrap = false)
                                        Text("${h.rainChance}%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, maxLines = 1, softWrap = false)
                                    }
                                }
                            }
                        }
                    }
                    item(key = "t-daily", contentType = "title") { SectionTitle(l.t("Dự báo ${b.daily.size} ngày", "${b.daily.size}-day forecast")) }
                    item(key = "daily", contentType = "daily") { Appear(4) { DailyCard(b, s, l) } }
                    item(key = "t-metrics", contentType = "title") { SectionTitle(l.t("Chỉ số thời tiết", "Weather details")) }

                    items(metricRows, key = { it.joinToString("+") }, contentType = { "metricRow" }) { r ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            r.forEach { MetricCard(it, b, s, l, Modifier.weight(1f)) }
                            if (r.size == 1 && r[0] != "sun") Spacer(Modifier.weight(1f))
                        }
                    }
                    item(key = "source", contentType = "source") {
                        Text(
                            l.t("Nguồn: ", "Source: ") + (if (b.source == "google") "Google Weather API" else "Open-Meteo.com (CC BY 4.0)"),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HeaderCard(b: WeatherBundle, s: AppSettings, l: L, place: Place, animate: Boolean, motion: String) {
    val c = b.current
    val sky = skyOf(c.code)
    val ink = MaterialTheme.colorScheme.onPrimaryContainer
    val updated = remember(b.fetchedAt, s.hour24, l.lang) {
        val iso = LocalDateTime.ofInstant(Instant.ofEpochMilli(b.fetchedAt), ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"))
        Fmt.clock(iso, s, l)
    }
    val today = b.daily.firstOrNull()
    val big = isBigFont()
    Box(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.extraLarge)
            .background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.tertiaryContainer)))
    ) {
        if (s.weatherBg) WeatherBackdrop(sky, c.isDay, animate, Modifier.matchParentSize())
        Column(Modifier.padding(22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(end = 12.dp)) {
                    Text(place.name, style = MaterialTheme.typography.titleLarge, color = ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        l.t("Cập nhật lúc ", "Updated at ") + updated,
                        style = MaterialTheme.typography.labelMedium,
                        color = ink.copy(alpha = 0.8f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Box(
                    Modifier
                        .size(if (big) 72.dp else 96.dp)
                        .clip(iconShape(s.iconShape))
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.35f)),
                    contentAlignment = Alignment.Center
                ) {
                    WeatherGlyph(sky, c.isDay, animate, Modifier.size(if (big) 50.dp else 68.dp))
                }
            }
            AnimatedContent(
                targetState = Fmt.temp(c.tempC, s),
                transitionSpec = {
                    if (motion == "off") fadeIn() togetherWith fadeOut()
                    else (slideInVertically(spring(stiffness = Spring.StiffnessMediumLow)) { it / 3 } + fadeIn()) togetherWith
                        (slideOutVertically { -it / 3 } + fadeOut())
                },
                label = "temp"
            ) { t ->
                // Số lớn tự co cho vừa chiều rộng (thay cho ép cứng 96.sp): "-12°F" hay cỡ chữ lớn đều không tràn.
                FitText(
                    t,
                    style = MaterialTheme.typography.displayLarge.copy(fontSize = 88.sp, lineHeight = 100.sp, fontWeight = FontWeight.Light),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                    color = ink
                )
            }
            Text(describe(c.code, l), style = MaterialTheme.typography.titleLarge, color = ink)
            Spacer(Modifier.height(4.dp))
            Text(
                buildString {
                    if (today != null) append(l.t("Cao ", "H ")).append(Fmt.temp(today.maxC, s)).append(l.t(" · Thấp ", " · L ")).append(Fmt.temp(today.minC, s)).append("  ·  ")
                    append(l.t("Cảm giác như ", "Feels like ")).append(Fmt.temp(c.feelsC, s))
                },
                style = MaterialTheme.typography.bodyLarge,
                color = ink
            )
        }
    }
}

@Composable
private fun DailyCard(b: WeatherBundle, s: AppSettings, l: L) {
    val days = b.daily
    if (days.isEmpty()) return
    val gMin = days.minOf { it.minC }
    val gMax = days.maxOf { it.maxC }
    val span = (gMax - gMin).coerceAtLeast(1.0)
    val track = MaterialTheme.colorScheme.surfaceVariant
    val c1 = MaterialTheme.colorScheme.tertiary
    val c2 = MaterialTheme.colorScheme.primary
    val t = MaterialTheme.typography
    // Bề rộng tối thiểu đo theo chuỗi mẫu và cỡ chữ hiệu dụng (không còn cột cố định 62/44/34dp).
    val tempMin = rememberTextWidthDp(if (s.tempUnit == "f") "-188°" else "-88°", t.bodyMedium)
    val rainMin = rememberTextWidthDp("100%", t.labelSmall)
    val dayMin = rememberTextWidthDp(l.t("Hôm nay", "Today"), t.bodyMedium)
    val big = isBigFont()
    Card28(Modifier.fillMaxWidth()) {
        BoxWithConstraints(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            val compact = big || maxWidth < 340.dp
            Column {
                days.forEachIndexed { i, d ->
                    val start = ((d.minC - gMin) / span).toFloat()
                    val end = ((d.maxC - gMin) / span).toFloat()
                    val bar = @Composable { m: Modifier ->
                        Canvas(m.padding(horizontal = 8.dp).height(8.dp)) {
                            val r = CornerRadius(size.height / 2)
                            drawRoundRect(track, cornerRadius = r)
                            val x0 = size.width * start
                            val x1 = (size.width * end).coerceAtLeast(x0 + size.height)
                            drawRoundRect(
                                Brush.horizontalGradient(listOf(c1, c2), startX = x0, endX = x1),
                                topLeft = Offset(x0, 0f),
                                size = Size(x1 - x0, size.height),
                                cornerRadius = r
                            )
                        }
                    }
                    val dayCol = @Composable { m: Modifier ->
                        Column(m) {
                            Text(Fmt.dayName(d.date, i, l), style = t.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(Fmt.dayShort(d.date), style = t.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                    }
                    val rain = @Composable {
                        Text(
                            d.rainChance?.let { "$it%" } ?: "",
                            Modifier.widthIn(min = rainMin).padding(start = 6.dp),
                            style = t.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                    if (compact) {
                        Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                dayCol(Modifier.weight(1f))
                                WeatherGlyph(skyOf(d.code), true, false, Modifier.size(30.dp))
                                rain()
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(Fmt.temp(d.minC, s), Modifier.widthIn(min = tempMin), color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, softWrap = false)
                                bar(Modifier.weight(1f))
                                Text(Fmt.temp(d.maxC, s), Modifier.widthIn(min = tempMin), textAlign = TextAlign.End, maxLines = 1, softWrap = false)
                            }
                        }
                    } else {
                        Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            dayCol(Modifier.widthIn(min = dayMin))
                            Spacer(Modifier.width(6.dp))
                            WeatherGlyph(skyOf(d.code), true, false, Modifier.size(30.dp))
                            rain()
                            Text(Fmt.temp(d.minC, s), Modifier.widthIn(min = tempMin), color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, softWrap = false)
                            bar(Modifier.weight(1f))
                            Text(Fmt.temp(d.maxC, s), Modifier.widthIn(min = tempMin), textAlign = TextAlign.End, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(key: String, b: WeatherBundle, s: AppSettings, l: L, modifier: Modifier) {
    val c = b.current
    val today = b.daily.firstOrNull()
    when (key) {
        "aqi" -> {
            val a = b.air
            MetricBox(Icons.Rounded.Air, l.t("Chất lượng không khí", "Air quality"), a?.usAqi?.toString() ?: "--",
                a?.let { aqiLabel(it.usAqi, l) + (it.pm25?.let { p -> " · PM2.5 ${p.toInt()}" } ?: "") } ?: l.t("Không có dữ liệu", "No data"), modifier)
        }
        "wind" -> MetricBox(Icons.Rounded.Speed, l.t("Gió", "Wind"), Fmt.wind(c.windKmh, s), compass(c.windDir, l) + " · ${c.windDir}°", modifier) {
            WindCompass(c.windDir)
        }
        "humidity" -> MetricBox(Icons.Rounded.WaterDrop, l.t("Độ ẩm", "Humidity"), "${c.humidity}%", l.t("Mây che phủ ", "Cloud cover ") + (c.cloud?.let { "$it%" } ?: "--"), modifier)
        "pressure" -> MetricBox(Icons.Rounded.Compress, l.t("Áp suất", "Pressure"), Fmt.pressure(c.pressure, s), l.t("Mực nước biển", "Sea level"), modifier)
        "visibility" -> MetricBox(Icons.Rounded.Visibility, l.t("Tầm nhìn", "Visibility"), c.visibilityKm?.let { Fmt.vis(it, s) } ?: "--", "", modifier)
        "uv" -> {
            val uv = maxOf(c.uv ?: 0.0, 0.0)
            val uvMax = today?.uvMax
            MetricBox(Icons.Rounded.LightMode, l.t("Chỉ số UV", "UV index"), if (c.uv == null && uvMax == null) "--" else uv.toInt().toString(),
                (if (c.uv != null) uvLabel(uv, l) else "") + (uvMax?.let { l.t(" · Cao nhất ${it.toInt()}", " · Max ${it.toInt()}") } ?: ""), modifier)
        }
        "rain" -> MetricBox(Icons.Rounded.WaterDrop, l.t("Khả năng mưa", "Rain chance"), "${today?.rainChance ?: c.rainChance ?: 0}%",
            today?.rainMm?.let { l.t("Lượng mưa ", "Amount ") + Fmt.rain(it, s) } ?: "", modifier)
        "sun" -> SunCard(today, c.time, s, l, modifier)
    }
}

@Composable
private fun MetricBox(
    icon: ImageVector,
    title: String,
    value: String,
    sub: String,
    modifier: Modifier,
    trailing: (@Composable () -> Unit)? = null
) {
    Card28(modifier) {
        BoxWithConstraints(Modifier.padding(16.dp)) {
            // Biểu đồ phụ (la bàn gió…) chỉ nằm cạnh cột chữ khi đủ rộng và chữ không quá lớn.
            val sideBySide = trailing != null && maxWidth >= 200.dp && !isBigFont()
            Column {
                IconText(icon, title, MaterialTheme.typography.labelLarge, textColor = MaterialTheme.colorScheme.onSurfaceVariant, gap = 6.dp)
                Spacer(Modifier.height(8.dp))
                if (sideBySide) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).widthIn(min = 72.dp)) { MetricText(value, sub) }
                        Spacer(Modifier.width(8.dp))
                        trailing?.invoke()
                    }
                } else {
                    MetricText(value, sub)
                    if (trailing != null) {
                        Spacer(Modifier.height(8.dp))
                        trailing()
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricText(value: String, sub: String) {
    Column {
        FitText(value, MaterialTheme.typography.headlineSmall, Modifier.fillMaxWidth(), minScale = 0.6f)
        if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun WindCompass(deg: Int) {
    val angle by animateFloatAsState(deg.toFloat(), spring(dampingRatio = 0.7f, stiffness = 200f), label = "wind")
    val ring = MaterialTheme.colorScheme.outlineVariant
    val arrow = MaterialTheme.colorScheme.primary
    Canvas(Modifier.size(52.dp)) {
        val r = size.minDimension / 2
        val ctr = Offset(r, r)
        drawCircle(ring, r - 2f, ctr, style = Stroke(3f))
        rotate(angle + 180f, ctr) {
            val p = Path().apply {
                moveTo(r, r * 0.25f); lineTo(r * 1.3f, r * 1.3f); lineTo(r, r * 1.08f); lineTo(r * 0.7f, r * 1.3f); close()
            }
            drawPath(p, arrow)
        }
    }
}

@Composable
private fun SunCard(day: DayW?, nowLocal: String, s: AppSettings, l: L, modifier: Modifier) {
    val rise = day?.sunrise
    val set = day?.sunset
    val frac = remember(rise, set, nowLocal) {
        runCatching {
            val a = LocalDateTime.parse(rise!!)
            val z = LocalDateTime.parse(set!!)
            val n = LocalDateTime.parse(nowLocal)
            val total = java.time.Duration.between(a, z).seconds.toFloat()
            (java.time.Duration.between(a, n).seconds / total).coerceIn(0f, 1f)
        }.getOrDefault(0.5f)
    }
    val track = MaterialTheme.colorScheme.outlineVariant
    val active = MaterialTheme.colorScheme.tertiary
    Card28(modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            IconText(Icons.Rounded.WbSunny, l.t("Mặt trời mọc / lặn", "Sunrise / sunset"), MaterialTheme.typography.labelLarge, textColor = MaterialTheme.colorScheme.onSurfaceVariant, gap = 6.dp)
            Canvas(Modifier.fillMaxWidth().height(110.dp).padding(top = 8.dp, start = 24.dp, end = 24.dp)) {
                val r = minOf(size.width / 2, size.height - 12f)
                val cx = size.width / 2
                val cy = size.height - 4f
                drawArc(track, 180f, 180f, false, Offset(cx - r, cy - r), Size(2 * r, 2 * r), style = Stroke(6f, cap = StrokeCap.Round))
                drawArc(active, 180f, 180f * frac, false, Offset(cx - r, cy - r), Size(2 * r, 2 * r), style = Stroke(6f, cap = StrokeCap.Round))
                val a = (PI + PI * frac).toFloat()
                drawCircle(active, 11f, Offset(cx + r * cos(a), cy + r * sin(a)))
            }
            Row(Modifier.fillMaxWidth()) {
                Text("↑ " + Fmt.clock(rise, s, l), Modifier.weight(1f), style = MaterialTheme.typography.titleSmall, maxLines = 1, softWrap = false)
                Text("↓ " + Fmt.clock(set, s, l), style = MaterialTheme.typography.titleSmall, maxLines = 1, softWrap = false)
            }
        }
    }
}
