package com.example.weatherm3.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

val ALL_CARDS = listOf("aqi", "wind", "humidity", "pressure", "visibility", "uv", "sun", "rain")

@Serializable
data class AppSettings(
    // Giao diện
    val theme: String = "system",          // system | light | dark | amoled
    val dynamicColor: Boolean = true,
    val seed: Int = 0xFF435D91.toInt(),
    val paletteStyle: String = "tonal",    // tonal | vibrant | expressive | neutral | mono | fidelity
    val contrast: Int = 0,                 // 0 chuẩn, 1 trung bình, 2 cao
    val language: String = "system",       // system | vi | en
    // Phông chữ
    val font: String = "default",
    val fontScale: Float = 1f,
    val fontWeight: Int = 1,               // 0 nhẹ, 1 chuẩn, 2 đậm
    val emphasized: Boolean = false,
    // Hình dạng & chuyển động
    val corners: String = "standard",      // square | standard | round | max
    val iconShape: String = "cookie",      // circle | cookie | flower | sunny | squircle
    val motion: String = "expressive",     // expressive | standard | off
    val haptics: Boolean = true,
    val weatherBg: Boolean = true,
    val weatherAnim: Boolean = true,
    val batterySaver: Boolean = false,
    // Đơn vị
    val tempUnit: String = "c",
    val windUnit: String = "kmh",          // kmh | ms | mph | kn | bft
    val pressureUnit: String = "hpa",      // hpa | mmhg | inhg
    val rainUnit: String = "mm",           // mm | in
    val visUnit: String = "km",            // km | mi
    val hour24: Boolean = true,
    // Dữ liệu
    val source: String = "openmeteo",      // openmeteo | google
    val googleKeyVersion: Int = 0,
    val refreshMinutes: Int = 60,
    val wifiOnly: Boolean = false,
    // Thông báo
    val dailyOn: Boolean = false,
    val dailyHour: Int = 7,
    val dailyMinute: Int = 0,
    val alertsOn: Boolean = false,
    val ongoingOn: Boolean = false,
    // Địa điểm
    val places: List<Place> = listOf(DEFAULT_PLACE),
    val activeId: String = "default",
    // Thẻ trang chủ
    val cardOrder: List<String> = ALL_CARDS,
    val hiddenCards: List<String> = emptyList()
) {
    fun activePlace(): Place =
        places.firstOrNull { it.id == activeId } ?: places.firstOrNull() ?: DEFAULT_PLACE

    fun orderedCards(): List<String> =
        cardOrder.filter { it in ALL_CARDS }.distinct().let { o -> o + ALL_CARDS.filter { it !in o } }
}

val AppJson = Json {
    ignoreUnknownKeys = true
    coerceInputValues = true
    encodeDefaults = true
    isLenient = true
}

private val Context.settingsStore by preferencesDataStore(name = "weather_settings_v2")

class SettingsRepository(private val ctx: Context) {
    private val key = stringPreferencesKey("json")

    private fun decode(raw: String?): AppSettings =
        raw?.let { runCatching { AppJson.decodeFromString<AppSettings>(it) }.getOrNull() } ?: AppSettings()

    val flow: Flow<AppSettings> = ctx.settingsStore.data.map { decode(it[key]) }

    suspend fun current(): AppSettings = flow.first()

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        ctx.settingsStore.edit { p ->
            val next = transform(decode(p[key]))
            p[key] = AppJson.encodeToString(next)
        }
    }
}
