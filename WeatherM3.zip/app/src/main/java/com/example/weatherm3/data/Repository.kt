package com.example.weatherm3.data

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import java.io.File
import java.util.Locale

data class LoadResult(val bundle: WeatherBundle, val stale: Boolean, val error: String?)

/** Bộ nhớ đệm JSON trong filesDir/wx (xem được offline, có TTL). */
object WeatherCache {
    const val TTL_MS = 10 * 60 * 1000L

    private fun dir(ctx: Context) = File(ctx.filesDir, "wx").apply { mkdirs() }

    fun key(place: Place, source: String): String =
        "${source}_${"%.2f".format(Locale.US, place.lat)}_${"%.2f".format(Locale.US, place.lon)}"

    fun load(ctx: Context, key: String): WeatherBundle? = runCatching {
        val f = File(dir(ctx), "$key.json")
        if (f.exists()) AppJson.decodeFromString<WeatherBundle>(f.readText()) else null
    }.getOrNull()

    fun save(ctx: Context, key: String, b: WeatherBundle) {
        runCatching { File(dir(ctx), "$key.json").writeText(AppJson.encodeToString(b)) }
    }

    fun clear(ctx: Context) {
        dir(ctx).listFiles()?.forEach { it.delete() }
    }
}

object Repo {
    /** Bỏ các giờ đã qua, giữ tối đa 72 giờ. */
    fun finalize(b: WeatherBundle): WeatherBundle {
        val hourStart = b.current.time.take(13) + ":00"
        val hours = b.hourly.filter { it.time >= hourStart }.take(72)
        return b.copy(hourly = hours)
    }

    suspend fun fetchAir(lat: Double, lon: Double): AirW? {
        val c = Net.air.air(lat, lon).current ?: return null
        val aqi = c.usAqi ?: return null
        return AirW(aqi.toInt(), c.pm25, c.pm10, c.ozone, c.no2)
    }

    private suspend fun fetchOpenMeteo(lat: Double, lon: Double): WeatherBundle {
        val r = Net.forecast.forecast(lat, lon)
        val c = r.current
        val h = r.hourly
        val hourStart = c.time.take(13) + ":00"
        val idx = h.time.indexOfFirst { it >= hourStart }.coerceAtLeast(0)

        val hourly = h.time.indices.drop(idx).take(72).mapNotNull { i ->
            val t = h.temp.getOrNull(i) ?: return@mapNotNull null
            HourW(
                time = h.time[i],
                tempC = t,
                rainChance = h.rain.getOrNull(i)?.toInt() ?: 0,
                code = h.code.getOrNull(i)?.toInt() ?: 0,
                isDay = (h.isDay.getOrNull(i) ?: 1.0) >= 0.5,
                windKmh = h.wind.getOrNull(i)
            )
        }
        val d = r.daily
        val daily = d.time.indices.mapNotNull { i ->
            val mx = d.max.getOrNull(i) ?: return@mapNotNull null
            val mn = d.min.getOrNull(i) ?: return@mapNotNull null
            DayW(
                date = d.time[i],
                code = d.code.getOrNull(i)?.toInt() ?: 0,
                maxC = mx,
                minC = mn,
                sunrise = d.sunrise.getOrNull(i),
                sunset = d.sunset.getOrNull(i),
                uvMax = d.uv.getOrNull(i),
                rainChance = d.rain.getOrNull(i)?.toInt(),
                rainMm = d.rainSum.getOrNull(i)
            )
        }
        val current = CurrentW(
            time = c.time,
            tempC = c.temp,
            feelsC = c.feels,
            humidity = c.humidity.toInt(),
            code = c.code.toInt(),
            isDay = c.isDay >= 0.5,
            windKmh = c.wind,
            windDir = c.windDir.toInt(),
            pressure = c.pressure,
            visibilityKm = h.visibility.getOrNull(idx)?.let { it / 1000.0 },
            uv = h.uv.getOrNull(idx),
            cloud = c.cloud.toInt(),
            rainChance = h.rain.getOrNull(idx)?.toInt()
        )
        val air = runCatching { fetchAir(lat, lon) }.getOrNull()
        return WeatherBundle(
            source = "openmeteo",
            fetchedAt = System.currentTimeMillis(),
            timezone = r.timezone,
            current = current,
            hourly = hourly,
            daily = daily,
            air = air
        )
    }

    fun cached(ctx: Context, place: Place, s: AppSettings): WeatherBundle? =
        WeatherCache.load(ctx, WeatherCache.key(place, s.source))

    suspend fun load(ctx: Context, place: Place, s: AppSettings, lang: String, force: Boolean): LoadResult {
        val key = WeatherCache.key(place, s.source)
        val cached = withContext(Dispatchers.IO) { WeatherCache.load(ctx, key) }
        if (!force && cached != null && System.currentTimeMillis() - cached.fetchedAt < WeatherCache.TTL_MS) {
            return LoadResult(cached, false, null)
        }
        return try {
            val fresh = if (s.source == "google") {
                val k = Secret.googleKey(ctx)
                    ?: throw IllegalStateException("Chưa nhập Google API key / No Google API key")
                GoogleWeather.fetch(k, place.lat, place.lon, lang)
            } else {
                fetchOpenMeteo(place.lat, place.lon)
            }
            withContext(Dispatchers.IO) { WeatherCache.save(ctx, key, fresh) }
            LoadResult(fresh, false, null)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (cached != null) LoadResult(cached, true, e.message) else throw e
        }
    }

    suspend fun search(q: String, lang: String): List<GeoResult> =
        Net.geo.search(q, language = lang).results
}
