import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "com.example.weatherm3"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.example.weatherm3"
        minSdk = 26
        targetSdk = 36
        versionCode = 4
        versionName = "3.0.1"
    }
    // Khóa KÝ CỐ ĐỊNH (khóa thử nghiệm, commit sẵn) để các bản build sau cài đè được lên bản cũ.
    // Dùng khóa riêng: đặt biến môi trường KEYSTORE_PATH / KEYSTORE_PASSWORD / KEY_ALIAS / KEY_PASSWORD (xem README).
    signingConfigs {
        create("shared") {
            storeFile = file(System.getenv("KEYSTORE_PATH") ?: "weatherm3-test.jks")
            storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "weatherm3test"
            keyAlias = System.getenv("KEY_ALIAS") ?: "weatherm3"
            keyPassword = System.getenv("KEY_PASSWORD") ?: "weatherm3test"
        }
    }
    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("shared")
        }
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    lint { abortOnError = false }
}

// Kotlin 2.4 đã bỏ khối android { kotlinOptions { } } -> dùng compilerOptions
kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

// Báo cáo ổn định Compose: gradle assembleRelease -PcomposeReports=true  -> app/build/compose_reports
if (project.hasProperty("composeReports")) {
    composeCompiler {
        reportsDestination.set(layout.buildDirectory.dir("compose_reports"))
        metricsDestination.set(layout.buildDirectory.dir("compose_metrics"))
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime)
    implementation(libs.androidx.lifecycle.compose)
    implementation(libs.androidx.viewmodel.compose)
    implementation(libs.androidx.datastore)
    implementation(libs.androidx.work)
    implementation(libs.androidx.splash)
    implementation(libs.androidx.profileinstaller)
    implementation(libs.androidx.glance.appwidget)
    implementation(libs.androidx.glance.material3)
    implementation(libs.material)
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.foundation)
    implementation(libs.compose.material3)
    implementation(libs.compose.icons)
    implementation(libs.retrofit)
    implementation(libs.retrofit.serialization)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.okhttp)
    debugImplementation(libs.compose.ui.tooling)
}
