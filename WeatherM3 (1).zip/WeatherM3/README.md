# Weather M3 (v2.0.0)

Ứng dụng thời tiết Android: Kotlin + Jetpack Compose + Material 3 Expressive.

## Có gì mới ở v2
- Nguồn dữ liệu: **Open-Meteo** (mặc định) hoặc **Google Weather API** (nhập API key trong Cài đặt, key được mã hóa bằng Android Keystore).
- **Chất lượng không khí (AQI)**, UV, gió (la bàn), áp suất, tầm nhìn, mặt trời mọc/lặn dạng cung.
- **Cache ngoại tuyến** (file JSON, TTL 10 phút) + nhãn "đang hiển thị dữ liệu đã lưu".
- **Radar mưa** RainViewer trên bản đồ (Leaflet + OpenStreetMap/CARTO) với thanh trượt thời gian.
- **Widget Glance** (2×2, 4×2, 4×4, màu động).
- **Màu**: Dynamic Color, seed color (18 màu + HEX + thanh sắc độ + lấy màu từ ảnh), 6 kiểu bảng màu, 3 mức tương phản.
- **Phông chữ**: 7 kiểu, tỷ lệ 80–150%, độ đậm, chữ nhấn mạnh.
- **Đổi ngôn ngữ Việt/Anh tức thời**, đổi theme sáng/tối/AMOLED có chuyển màu mượt.
- Icon thời tiết tự vẽ có hoạt ảnh (thay cho Lottie), nền động mưa/tuyết/sao.
- **Sao lưu / khôi phục** cài đặt ra file JSON.
- **Thông báo**: dự báo hằng ngày, cảnh báo mưa/dông/nhiệt độ cực đoan, thông báo cố định.

## Build ra APK trên GitHub (làm trên điện thoại cũng được)
Xem hướng dẫn trong cuộc trò chuyện. Tóm tắt: đưa `WeatherM3.zip` (hoặc các file đã giải nén) lên repo, workflow
`.github/workflows/build-apk.yml` tự giải nén & build, rồi tải artifact `WeatherM3-debug-apk` ở tab **Actions**.

## Ghi chú kỹ thuật
- Kotlin 2.4.21, AGP 8.13.2, Gradle 8.13, Compose BOM 2026.09.00, minSdk 26.
- Không dùng Hilt/Room/KSP (giảm rủi ro lỗi build): DI thủ công, cache bằng file JSON.
- Mọi API "Expressive" nằm trong `ui/theme/Expressive.kt`.
