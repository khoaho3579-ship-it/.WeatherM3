# PERFORMANCE

**Chưa đo trên máy thật.** Không có số FPS nào được khẳng định trong tài liệu này.

## Cách tự đo
1. Cài bản **release** (artifact `WeatherM3-release-apk`), bật Cài đặt → Dành cho nhà phát triển → **Lớp phủ FPS** (xanh: p95 ≤ chu kỳ màn hình; vàng ≤ 1.5×; đỏ: cao hơn).
2. `adb shell dumpsys gfxinfo com.example.weatherm3 reset` → thao tác (cuộn Hôm nay, đổi 5 tab, cuộn Cài đặt) → `adb shell dumpsys gfxinfo com.example.weatherm3 framestats`.
3. Android Studio → Layout Inspector → "Recomposition counts" (đo `WeatherTheme` khi đổi theme; kỳ vọng vài lần/320ms, không phải vô hạn).
4. Báo cáo ổn định Compose: artifact `compose-reports` của CI (hoặc `gradle assembleRelease -PcomposeReports=true`).

## Bảng trước / sau (điền tay)
| Kịch bản | Debug v2.0.0 | Release v3.0.0 |
|---|---|---|
| Jank % khi cuộn Hôm nay | | |
| Jank % khi đổi tab | | |
| Jank % khi cuộn Cài đặt | | |
| p95 frame (ms) | | |
| Khởi động nguội (ms) | | |

## Vấn đề → thay đổi
Xem CHANGELOG (mục Hiệu năng). Giới hạn đã biết: khi đổi theme, `WeatherTheme` vẫn recomposition mỗi frame trong ~320ms
(bảng màu M3 được đọc trong composition); mục tiêu "đọc muộn trong draw" **chưa** đạt.

## Chống tràn
Điểm đã sửa: DailyCard, Forecast (giờ/ngày), MetricBox, HeaderCard, NavigationBar/Rail, Settings (Segmented, nút, tiêu đề nhóm), Places.
`@Preview` ma trận (fontScale 0.85–2.0 × 320–600dp × vi/en) **chưa viết**; tạm thời dùng "Chế độ thử tràn chữ" (×2.0) trong Cài đặt.

## Chưa làm
Phông nhúng, Baseline Profile, UI model, WindowSizeClass, đồng hồ hoạt ảnh chung/30 FPS, Predictive Back, mục 5–7 của prompt.
