package com.example.weatherm3.ui.theme

import android.graphics.Typeface
import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.weatherm3.core.L
import com.example.weatherm3.core.LocalL
import com.example.weatherm3.core.resolveLang
import com.example.weatherm3.data.AppSettings

val LocalAppSettings = compositionLocalOf { AppSettings() }
/** "expressive" | "standard" | "off" */
val LocalMotion = compositionLocalOf { "expressive" }

val FONT_KEYS = listOf("default", "sans", "condensed", "serif", "mono", "casual", "cursive")

fun fontFamilyFor(key: String): FontFamily = when (key) {
    "sans" -> FontFamily.SansSerif
    "serif" -> FontFamily.Serif
    "mono" -> FontFamily.Monospace
    "cursive" -> FontFamily.Cursive
    "condensed" -> FontFamily(Typeface.create("sans-serif-condensed", Typeface.NORMAL))
    "casual" -> FontFamily(Typeface.create("casual", Typeface.NORMAL))
    else -> FontFamily.Default
}

fun buildTypography(s: AppSettings): Typography {
    val family = fontFamilyFor(s.font)
    val scale = s.fontScale.coerceIn(0.8f, 1.5f)
    val shift = when (s.fontWeight) { 0 -> -100; 2 -> 150; else -> 0 }
    val emph = if (s.emphasized) 100 else 0
    fun TextStyle.adj(extra: Int = 0): TextStyle {
        val w = ((fontWeight ?: FontWeight.Normal).weight + shift + extra).coerceIn(100, 900)
        return copy(
            fontFamily = family,
            fontWeight = FontWeight(w),
            fontSize = fontSize * scale,
            lineHeight = lineHeight * scale
        )
    }
    val b = Typography()
    return Typography(
        displayLarge = b.displayLarge.adj(), displayMedium = b.displayMedium.adj(), displaySmall = b.displaySmall.adj(),
        headlineLarge = b.headlineLarge.adj(emph), headlineMedium = b.headlineMedium.adj(emph), headlineSmall = b.headlineSmall.adj(emph),
        titleLarge = b.titleLarge.adj(emph), titleMedium = b.titleMedium.adj(emph), titleSmall = b.titleSmall.adj(emph),
        bodyLarge = b.bodyLarge.adj(), bodyMedium = b.bodyMedium.adj(), bodySmall = b.bodySmall.adj(),
        labelLarge = b.labelLarge.adj(emph), labelMedium = b.labelMedium.adj(emph), labelSmall = b.labelSmall.adj(emph)
    )
}

fun buildShapes(style: String): Shapes {
    val f = when (style) { "square" -> 0.3f; "round" -> 1.4f; "max" -> 2f; else -> 1f }
    fun r(v: Float) = RoundedCornerShape((v * f).dp)
    return Shapes(extraSmall = r(4f), small = r(8f), medium = r(12f), large = r(16f), extraLarge = r(28f))
}

@Composable
private fun ColorScheme.animated(): ColorScheme {
    val spec = spring<Color>(stiffness = Spring.StiffnessLow)
    @Composable fun a(c: Color): Color = animateColorAsState(c, spec, label = "scheme").value
    return copy(
        primary = a(primary), onPrimary = a(onPrimary),
        primaryContainer = a(primaryContainer), onPrimaryContainer = a(onPrimaryContainer),
        inversePrimary = a(inversePrimary),
        secondary = a(secondary), onSecondary = a(onSecondary),
        secondaryContainer = a(secondaryContainer), onSecondaryContainer = a(onSecondaryContainer),
        tertiary = a(tertiary), onTertiary = a(onTertiary),
        tertiaryContainer = a(tertiaryContainer), onTertiaryContainer = a(onTertiaryContainer),
        background = a(background), onBackground = a(onBackground),
        surface = a(surface), onSurface = a(onSurface),
        surfaceVariant = a(surfaceVariant), onSurfaceVariant = a(onSurfaceVariant),
        surfaceTint = a(surfaceTint),
        inverseSurface = a(inverseSurface), inverseOnSurface = a(inverseOnSurface),
        error = a(error), onError = a(onError),
        errorContainer = a(errorContainer), onErrorContainer = a(onErrorContainer),
        outline = a(outline), outlineVariant = a(outlineVariant),
        surfaceBright = a(surfaceBright), surfaceDim = a(surfaceDim),
        surfaceContainerLowest = a(surfaceContainerLowest), surfaceContainerLow = a(surfaceContainerLow),
        surfaceContainer = a(surfaceContainer), surfaceContainerHigh = a(surfaceContainerHigh),
        surfaceContainerHighest = a(surfaceContainerHighest)
    )
}

fun isDarkFor(s: AppSettings, system: Boolean): Boolean = when (s.theme) {
    "dark", "amoled" -> true
    "light" -> false
    else -> system
}

@Composable
fun WeatherTheme(s: AppSettings, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = isDarkFor(s, isSystemInDarkTheme())
    var scheme: ColorScheme =
        if (s.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        } else {
            seedColorScheme(s.seed, dark, s.paletteStyle, s.contrast)
        }
    if (dark && s.theme == "amoled") {
        scheme = scheme.copy(
            background = Color.Black, surface = Color.Black, surfaceDim = Color.Black,
            surfaceContainerLowest = Color.Black, surfaceContainerLow = Color(0xFF0B0B0B),
            surfaceContainer = Color(0xFF121212), surfaceContainerHigh = Color(0xFF1A1A1A),
            surfaceContainerHighest = Color(0xFF222222)
        )
    }
    val animatedScheme = if (s.motion == "off") scheme else scheme.animated()
    CompositionLocalProvider(
        LocalAppSettings provides s,
        LocalMotion provides s.motion,
        LocalL provides L(resolveLang(s.language))
    ) {
        ExpressiveTheme(
            colorScheme = animatedScheme,
            motion = s.motion,
            shapes = buildShapes(s.corners),
            typography = buildTypography(s),
            content = content
        )
    }
}
