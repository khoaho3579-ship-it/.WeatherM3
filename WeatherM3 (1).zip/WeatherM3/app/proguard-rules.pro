# Keep serialization model metadata when minifying release builds.
-keepattributes *Annotation*, InnerClasses, EnclosingMethod
