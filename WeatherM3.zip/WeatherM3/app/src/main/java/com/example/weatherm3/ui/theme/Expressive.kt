@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.example.weatherm3.ui.theme

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.LinearWavyProgressIndicator
import androidx.compose.material3.LoadingIndicator
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MaterialShapes
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.toShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/** Tất cả API "Expressive" (thử nghiệm) được gom vào file này để dễ sửa nếu thư viện đổi tên. */
@Composable
fun ExpressiveTheme(
    colorScheme: ColorScheme,
    motion: String,
    shapes: Shapes,
    typography: Typography,
    content: @Composable () -> Unit
) {
    MaterialExpressiveTheme(
        colorScheme = colorScheme,
        motionScheme = if (motion == "expressive") MotionScheme.expressive() else MotionScheme.standard(),
        shapes = shapes,
        typography = typography,
        content = content
    )
}

/** Vòng tải biến hình (đa giác đổi dạng liên tục). */
@Composable
fun AppLoadingIndicator(modifier: Modifier = Modifier) {
    LoadingIndicator(modifier = modifier)
}

/** Thanh tiến trình dạng sóng. */
@Composable
fun AppWavyProgress(progress: Float, modifier: Modifier = Modifier) {
    LinearWavyProgressIndicator(progress = { progress }, modifier = modifier)
}

/** Khung hình icon: circle | cookie | flower | sunny | squircle (MaterialShapes M3 Expressive). */
@Composable
fun iconShape(key: String): Shape = remember(key) {
    when (key) {
        "circle" -> CircleShape
        "flower" -> MaterialShapes.Flower.toShape()
        "sunny" -> MaterialShapes.Sunny.toShape()
        "squircle" -> RoundedCornerShape(28.dp)
        else -> MaterialShapes.Cookie9Sided.toShape()
    }
}
