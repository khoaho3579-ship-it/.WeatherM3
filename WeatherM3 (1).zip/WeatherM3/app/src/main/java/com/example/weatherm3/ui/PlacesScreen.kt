@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.weatherm3.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.weatherm3.core.LocalL
import com.example.weatherm3.ui.components.AppLoadingCenter
import com.example.weatherm3.ui.theme.AppLoadingIndicator
import kotlinx.coroutines.delay

@Composable
fun PlacesScreen(vm: AppViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val l = LocalL.current
    var showSearch by remember { mutableStateOf(false) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) vm.useGps()
        else vm.notifyMessage("Chưa cấp quyền vị trí", "Location permission not granted")
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(l.t("Địa điểm", "Locations")) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showSearch = true },
                icon = { Icon(Icons.Rounded.Add, null) },
                text = { Text(l.t("Thêm địa điểm", "Add location")) }
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                FilledTonalButton(onClick = {
                    permLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                }) {
                    Icon(Icons.Rounded.MyLocation, null)
                    Spacer(Modifier.width(8.dp))
                    Text(l.t("Dùng vị trí hiện tại (GPS)", "Use my location (GPS)"))
                }
            }
            items(s.places, key = { it.id }) { p ->
                val active = p.id == s.activeId
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.extraLarge)
                        .background(if (active) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainer)
                        .clickable { vm.setActive(p.id) }
                        .padding(start = 8.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = active, onClick = { vm.setActive(p.id) })
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (p.gps) {
                                Icon(Icons.Rounded.MyLocation, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(4.dp))
                            }
                            Text(p.name, style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            (if (p.sub.isNotEmpty()) p.sub + " · " else "") + "%.2f, %.2f".format(p.lat, p.lon),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { vm.movePlace(p.id, -1) }) { Icon(Icons.Rounded.ArrowUpward, l.t("Lên", "Up")) }
                    IconButton(onClick = { vm.movePlace(p.id, 1) }) { Icon(Icons.Rounded.ArrowDownward, l.t("Xuống", "Down")) }
                    IconButton(onClick = { vm.removePlace(p.id) }) { Icon(Icons.Rounded.Delete, l.t("Xóa", "Delete")) }
                }
            }
        }
    }

    if (showSearch) SearchDialog(vm) { showSearch = false }
}

@Composable
fun SearchDialog(vm: AppViewModel, onClose: () -> Unit) {
    val l = LocalL.current
    val results by vm.searchResults.collectAsStateWithLifecycle()
    val searching by vm.searching.collectAsStateWithLifecycle()
    var text by remember { mutableStateOf("") }
    LaunchedEffect(text) {
        delay(400)
        vm.search(text)
    }
    AlertDialog(
        onDismissRequest = { vm.clearSearch(); onClose() },
        title = { Text(l.t("Tìm thành phố", "Search city")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text(l.t("Tên thành phố", "City name")) },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (searching) AppLoadingIndicator(Modifier.size(40.dp))
                results.forEach { r ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(MaterialTheme.shapes.large)
                            .clickable { vm.addPlace(r); vm.clearSearch(); onClose() }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Place, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(r.name, style = MaterialTheme.typography.titleSmall)
                            Text(
                                listOfNotNull(r.admin1, r.country.ifBlank { null }).joinToString(", "),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.clearSearch(); onClose() }) { Text(l.t("Đóng", "Close")) } }
    )
}
