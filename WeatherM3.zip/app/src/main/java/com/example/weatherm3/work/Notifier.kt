package com.example.weatherm3.work

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.weatherm3.MainActivity
import com.example.weatherm3.R
import com.example.weatherm3.core.Fmt
import com.example.weatherm3.core.Insights
import com.example.weatherm3.core.L
import com.example.weatherm3.core.describe
import com.example.weatherm3.core.resolveLang
import com.example.weatherm3.data.AppSettings
import com.example.weatherm3.data.WeatherBundle

object Notifier {
    private const val CH_DAILY = "daily"
    private const val CH_ALERT = "alerts"
    private const val CH_ONGOING = "ongoing"
    const val ID_DAILY = 1001
    const val ID_ALERT = 1002
    const val ID_ONGOING = 1003

    fun lang(s: AppSettings) = L(resolveLang(s.language))

    private fun canPost(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    private fun ensureChannels(ctx: Context, l: L) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_DAILY, l.t("Dự báo hằng ngày", "Daily forecast"), NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, l.t("Cảnh báo thời tiết", "Weather alerts"), NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_ONGOING, l.t("Thông báo cố định", "Ongoing"), NotificationManager.IMPORTANCE_LOW))
    }

    private fun openApp(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun post(ctx: Context, id: Int, channel: String, title: String, text: String, ongoing: Boolean = false) {
        if (!canPost(ctx)) return
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_weather)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openApp(ctx))
            .setOngoing(ongoing)
            .setOnlyAlertOnce(ongoing)
            .setAutoCancel(!ongoing)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (_: SecurityException) {
        }
    }

    fun daily(ctx: Context, b: WeatherBundle, s: AppSettings) {
        val l = lang(s)
        ensureChannels(ctx, l)
        val d = b.daily.firstOrNull()
        val title = "${s.activePlace().name}: ${Fmt.temp(b.current.tempC, s)} · ${describe(b.current.code, l)}"
        val text = buildString {
            if (d != null) append(l.t("Cao ", "High ")).append(Fmt.temp(d.maxC, s)).append(l.t(" / thấp ", " / low ")).append(Fmt.temp(d.minC, s))
            val rain = b.hourly.take(12).maxOfOrNull { it.rainChance } ?: 0
            append(l.t(" · Mưa tối đa $rain% trong 12 giờ tới", " · Up to $rain% rain in the next 12h"))
            Insights.tips(b, s, l).firstOrNull()?.let { append("\n").append(it) }
        }
        post(ctx, ID_DAILY, CH_DAILY, title, text)
    }

    fun alerts(ctx: Context, b: WeatherBundle, s: AppSettings) {
        val l = lang(s)
        val list = Insights.alerts(b, l)
        if (list.isEmpty()) return
        val prefs = ctx.getSharedPreferences("alert_state", Context.MODE_PRIVATE)
        val sig = b.current.time.take(10) + "|" + list.joinToString(";")
        if (prefs.getString("last", null) == sig) return
        prefs.edit().putString("last", sig).apply()
        ensureChannels(ctx, l)
        post(ctx, ID_ALERT, CH_ALERT, l.t("Cảnh báo thời tiết · ", "Weather alert · ") + s.activePlace().name, list.joinToString("\n"))
    }

    fun ongoing(ctx: Context, b: WeatherBundle, s: AppSettings) {
        val nm = NotificationManagerCompat.from(ctx)
        if (!s.ongoingOn) {
            nm.cancel(ID_ONGOING)
            return
        }
        val l = lang(s)
        ensureChannels(ctx, l)
        post(
            ctx, ID_ONGOING, CH_ONGOING,
            "${s.activePlace().name}: ${Fmt.temp(b.current.tempC, s)}",
            "${describe(b.current.code, l)} · ${l.t("Cảm giác như", "Feels like")} ${Fmt.temp(b.current.feelsC, s)}",
            ongoing = true
        )
    }
}
