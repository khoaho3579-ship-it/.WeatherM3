package com.example.weatherm3.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import com.example.weatherm3.core.Sky
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val SunGold = Color(0xFFFFC83D)
private val MoonPale = Color(0xFFE6E9F5)
private val CloudLight = Color(0xFFF1F4F8)
private val CloudGray = Color(0xFFB3BFCB)
private val CloudDark = Color(0xFF8795A3)
private val RainBlue = Color(0xFF5AB2FF)
private val BoltYellow = Color(0xFFFFE066)

private fun DrawScope.sun(cx: Float, cy: Float, r: Float, t: Float) {
    rotate(degrees = t * 360f, pivot = Offset(cx, cy)) {
        for (i in 0 until 8) {
            val a = i * (PI / 4)
            val dx = cos(a).toFloat()
            val dy = sin(a).toFloat()
            drawLine(
                SunGold,
                Offset(cx + dx * r * 1.38f, cy + dy * r * 1.38f),
                Offset(cx + dx * r * 1.78f, cy + dy * r * 1.78f),
                strokeWidth = r * 0.3f,
                cap = StrokeCap.Round
            )
        }
    }
    drawCircle(SunGold, r, Offset(cx, cy))
}

private fun DrawScope.moon(cx: Float, cy: Float, r: Float) {
    val cut = Path().apply {
        addOval(Rect(center = Offset(cx + r * 0.55f, cy - r * 0.25f), radius = r * 0.85f))
    }
    clipPath(cut, ClipOp.Difference) { drawCircle(MoonPale, r, Offset(cx, cy)) }
}

private fun DrawScope.cloud(x: Float, y: Float, w: Float, color: Color) {
    val h = w * 0.62f
    drawCircle(color, h * 0.42f, Offset(x + w * 0.28f, y + h * 0.62f))
    drawCircle(color, h * 0.55f, Offset(x + w * 0.52f, y + h * 0.42f))
    drawCircle(color, h * 0.38f, Offset(x + w * 0.76f, y + h * 0.64f))
    drawRoundRect(color, Offset(x + w * 0.1f, y + h * 0.6f), Size(w * 0.8f, h * 0.4f), CornerRadius(h * 0.2f))
}

private fun DrawScope.rain(w: Float, t: Float, heavy: Boolean) {
    val n = if (heavy) 5 else 3
    for (i in 0 until n) {
        val x = w * (0.28f + i * (0.44f / (n - 1).coerceAtLeast(1)))
        val p = (t * 2f + i * 0.31f) % 1f
        val y = w * (0.58f + 0.36f * p)
        drawLine(
            RainBlue, Offset(x, y), Offset(x - w * 0.03f, y + w * 0.09f),
            strokeWidth = w * 0.035f, cap = StrokeCap.Round, alpha = 1f - p * 0.6f
        )
    }
}

private fun DrawScope.snow(w: Float, t: Float) {
    for (i in 0 until 5) {
        val p = (t + i * 0.2f) % 1f
        val x = w * (0.24f + i * 0.13f) + sin((p * 2 * PI + i).toFloat()) * w * 0.03f
        val y = w * (0.58f + 0.36f * p)
        drawCircle(Color.White, w * 0.028f, Offset(x, y), alpha = 1f - p * 0.5f)
    }
}

private fun DrawScope.bolt(w: Float, t: Float) {
    val flash = if (t % 1f in 0.55f..0.7f || t % 1f in 0.78f..0.86f) 1f else 0.55f
    val p = Path().apply {
        moveTo(w * 0.52f, w * 0.56f); lineTo(w * 0.40f, w * 0.78f); lineTo(w * 0.50f, w * 0.78f)
        lineTo(w * 0.44f, w * 0.97f); lineTo(w * 0.64f, w * 0.72f); lineTo(w * 0.53f, w * 0.72f)
        lineTo(w * 0.60f, w * 0.56f); close()
    }
    drawPath(p, BoltYellow, alpha = flash)
}

@Composable
private fun clock(animate: Boolean, ms: Int): State<Float>? {
    if (!animate) return null
    val tr = rememberInfiniteTransition(label = "glyph")
    return tr.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(ms, easing = LinearEasing), RepeatMode.Restart),
        label = "t"
    )
}

/** Icon thời tiết tự vẽ (bo tròn, có hoạt ảnh nhẹ: mặt trời xoay, mây trôi, mưa rơi, sét nháy). */
@Composable
fun WeatherGlyph(sky: Sky, isDay: Boolean, animate: Boolean, modifier: Modifier = Modifier) {
    val st = clock(animate, 4000)
    Canvas(modifier.aspectRatio(1f)) {
        val t = st?.value ?: 0f
        val w = size.minDimension
        val sway = sin((t * 2 * PI).toFloat()) * w * 0.02f
        when (sky) {
            Sky.CLEAR -> if (isDay) sun(w * 0.5f, w * 0.5f, w * 0.22f, t) else moon(w * 0.5f, w * 0.5f, w * 0.3f)
            Sky.PARTLY -> {
                if (isDay) sun(w * 0.64f, w * 0.36f, w * 0.16f, t) else moon(w * 0.62f, w * 0.36f, w * 0.2f)
                cloud(w * 0.08f + sway, w * 0.34f, w * 0.78f, CloudLight)
            }
            Sky.CLOUDY -> {
                cloud(w * 0.18f - sway, w * 0.2f, w * 0.64f, CloudGray)
                cloud(w * 0.06f + sway, w * 0.36f, w * 0.8f, CloudLight)
            }
            Sky.FOG -> {
                cloud(w * 0.1f + sway, w * 0.14f, w * 0.78f, CloudGray)
                for (i in 0 until 3) {
                    drawLine(CloudLight, Offset(w * 0.2f, w * (0.62f + i * 0.12f)), Offset(w * 0.8f, w * (0.62f + i * 0.12f)),
                        strokeWidth = w * 0.05f, cap = StrokeCap.Round)
                }
            }
            Sky.DRIZZLE, Sky.RAIN -> {
                cloud(w * 0.1f + sway, w * 0.14f, w * 0.78f, CloudGray)
                rain(w, t, sky == Sky.RAIN)
            }
            Sky.SNOW -> {
                cloud(w * 0.1f + sway, w * 0.14f, w * 0.78f, CloudLight)
                snow(w, t)
            }
            Sky.STORM -> {
                cloud(w * 0.1f + sway, w * 0.1f, w * 0.78f, CloudDark)
                bolt(w, t)
            }
        }
    }
}

/** Nền động trong thẻ chính: mưa, tuyết, sao, quầng nắng. Tắt được trong Cài đặt / tiết kiệm pin. */
@Composable
fun WeatherBackdrop(sky: Sky, isDay: Boolean, animate: Boolean, modifier: Modifier = Modifier) {
    val st = clock(animate, 6000)
    val ink = MaterialTheme.colorScheme.onPrimaryContainer
    val glow = MaterialTheme.colorScheme.tertiary
    Canvas(modifier) {
        val t = st?.value ?: 0f
        val w = size.width
        val h = size.height
        when {
            sky == Sky.RAIN || sky == Sky.DRIZZLE || sky == Sky.STORM -> {
                val n = if (sky == Sky.DRIZZLE) 14 else 26
                for (i in 0 until n) {
                    val x = ((i * 37) % 100) / 100f * w
                    val p = (t * (2f + (i % 3)) + i * 0.137f) % 1f
                    val y = p * h
                    drawLine(ink, Offset(x, y), Offset(x - 6f, y + 24f), strokeWidth = 2.5f, cap = StrokeCap.Round, alpha = 0.22f)
                }
            }
            sky == Sky.SNOW -> {
                for (i in 0 until 24) {
                    val x = ((i * 53) % 100) / 100f * w + sin((t * 2 * PI + i).toFloat()) * 10f
                    val p = (t * (1f + (i % 3) * 0.5f) + i * 0.171f) % 1f
                    drawCircle(ink, 3.5f + (i % 3), Offset(x, p * h), alpha = 0.3f)
                }
            }
            !isDay && sky == Sky.CLEAR -> {
                for (i in 0 until 22) {
                    val x = ((i * 61) % 100) / 100f * w
                    val y = ((i * 29) % 100) / 100f * h
                    val a = 0.15f + 0.3f * (0.5f + 0.5f * sin((t * 2 * PI + i).toFloat()))
                    drawCircle(ink, 2.5f, Offset(x, y), alpha = a)
                }
            }
            isDay && (sky == Sky.CLEAR || sky == Sky.PARTLY) -> {
                val pulse = 0.85f + 0.15f * sin((t * 2 * PI).toFloat())
                drawCircle(glow, w * 0.38f * pulse, Offset(w * 0.9f, h * 0.05f), alpha = 0.18f)
                drawCircle(glow, w * 0.22f * pulse, Offset(w * 0.9f, h * 0.05f), alpha = 0.18f)
            }
        }
    }
}
