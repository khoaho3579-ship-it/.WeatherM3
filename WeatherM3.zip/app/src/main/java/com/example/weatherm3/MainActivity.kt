package com.example.weatherm3

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.weatherm3.ui.AppViewModel
import com.example.weatherm3.ui.WeatherApp
import com.example.weatherm3.ui.theme.WeatherTheme
import com.example.weatherm3.ui.theme.isDarkFor

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { !vm.ready.value }
        splash.setOnExitAnimationListener { p ->
            p.view.animate().alpha(0f).scaleX(1.2f).scaleY(1.2f).setDuration(350L)
                .withEndAction { p.remove() }.start()
        }
        enableEdgeToEdge()
        setContent {
            val s by vm.settings.collectAsStateWithLifecycle()
            val dark = isDarkFor(s, isSystemInDarkTheme())
            LaunchedEffect(dark) {
                this@MainActivity.enableEdgeToEdge(
                    statusBarStyle = if (dark) SystemBarStyle.dark(Color.TRANSPARENT) else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
                    navigationBarStyle = if (dark) SystemBarStyle.dark(Color.TRANSPARENT) else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                )
            }
            WeatherTheme(s) { WeatherApp(vm) }
        }
    }
}
