package com.example.weatherm3.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * Nguồn dữ liệu Google Maps Platform – Weather API (weather.googleapis.com).
 * Cần API key riêng, đã bật "Weather API" và billing/Demo Key. Hãy tự kiểm tra tài liệu/giá hiện hành của Google.
 * Phần đọc JSON viết theo kiểu "khoan dung": thiếu trường nào thì bỏ qua trường đó, không làm app crash.
 */
object GoogleWeather {
    private val MIN_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm")

    private fun JsonElement?.at(vararg path: String): JsonElement? {
        var c: JsonElement? = this
        for (p in path) {
            c = (c as? JsonObject)?.get(p) ?: return null
        }
        return c
    }

    private fun JsonElement?.dbl(): Double? = (this as? JsonPrimitive)?.doubleOrNull
    private fun JsonElement?.str(): String? = (this as? JsonPrimitive)?.contentOrNull
    private fun JsonElement?.bool(): Boolean? = (this as? JsonPrimitive)?.booleanOrNull

    fun code(type: String?): Int {
        val t = type ?: return 2
        return when {
            "THUNDER" in t -> 95
            "SNOW" in t || "BLIZZARD" in t || "FLURR" in t -> 73
            "HAIL" in t -> 96
            "SHOWER" in t -> if ("HEAVY" in t) 82 else 80
            "HEAVY" in t && "RAIN" in t -> 65
            "LIGHT" in t && "RAIN" in t -> 61
            "RAIN" in t -> 63
            "DRIZZLE" in t -> 51
            "FOG" in t || "HAZE" in t || "SMOKE" in t -> 45
            t.startsWith("PARTLY") -> 2
            "CLOUDY" in t -> 3
            t == "MOSTLY_CLEAR" -> 1
            "CLEAR" in t -> 0
            else -> 2
        }
    }

    private suspend fun call(
        path: String,
        key: String,
        lat: Double,
        lon: Double,
        lang: String,
        extra: Map<String, String>
    ): JsonObject = withContext(Dispatchers.IO) {
        val b = "https://weather.googleapis.com/$path".toHttpUrl().newBuilder()
            .addQueryParameter("key", key)
            .addQueryParameter("location.latitude", lat.toString())
            .addQueryParameter("location.longitude", lon.toString())
            .addQueryParameter("languageCode", lang)
        for ((k, v) in extra) b.addQueryParameter(k, v)
        Net.client.newCall(Request.Builder().url(b.build()).build()).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) {
                val msg = runCatching {
                    Net.json.parseToJsonElement(body).at("error", "message").str()
                }.getOrNull()
                throw IllegalStateException("Google Weather API ${r.code}: ${msg ?: "lỗi không rõ"}")
            }
            Net.json.parseToJsonElement(body) as? JsonObject ?: JsonObject(emptyMap())
        }
    }

    suspend fun fetch(key: String, lat: Double, lon: Double, lang: String): WeatherBundle = coroutineScope {
        val cur = async { call("v1/currentConditions:lookup", key, lat, lon, lang, emptyMap()) }
        val hours = async {
            val items = mutableListOf<JsonElement>()
            var tz: String? = null
            var token: String? = null
            for (page in 0 until 3) {
                val extra = mutableMapOf("hours" to "72", "pageSize" to "24")
                token?.let { extra["pageToken"] = it }
                val o = call("v1/forecast/hours:lookup", key, lat, lon, lang, extra)
                (o["forecastHours"] as? JsonArray)?.let { items.addAll(it) }
                tz = tz ?: o.at("timeZone", "id").str()
                token = o.at("nextPageToken").str()
                if (token.isNullOrEmpty()) break
            }
            Pair(items, tz)
        }
        val days = async {
            call("v1/forecast/days:lookup", key, lat, lon, lang, mapOf("days" to "10", "pageSize" to "10"))
        }
        val alerts = async { runCatching { call("v1/publicAlerts:lookup", key, lat, lon, lang, emptyMap()) }.getOrNull() }
        val air = async { runCatching { Repo.fetchAir(lat, lon) }.getOrNull() }

        val c = cur.await()
        val (hourItems, hourTz) = hours.await()
        val d = days.await()
        val tz = c.at("timeZone", "id").str() ?: hourTz ?: "UTC"
        val zone = runCatching { ZoneId.of(tz) }.getOrDefault(ZoneId.of("UTC"))

        fun loc(iso: String?): String? = iso?.let {
            runCatching { Instant.parse(it).atZone(zone).toLocalDateTime().format(MIN_FMT) }.getOrNull()
        }

        val nowLocal = loc(c.at("currentTime").str()) ?: java.time.LocalDateTime.now(zone).format(MIN_FMT)
        val isDay = c.at("isDaytime").bool() ?: true
        val current = CurrentW(
            time = nowLocal,
            tempC = c.at("temperature", "degrees").dbl() ?: 0.0,
            feelsC = c.at("feelsLikeTemperature", "degrees").dbl() ?: c.at("temperature", "degrees").dbl() ?: 0.0,
            humidity = c.at("relativeHumidity").dbl()?.toInt() ?: 0,
            code = code(c.at("weatherCondition", "type").str()),
            isDay = isDay,
            windKmh = c.at("wind", "speed", "value").dbl() ?: 0.0,
            windDir = c.at("wind", "direction", "degrees").dbl()?.toInt() ?: 0,
            pressure = c.at("airPressure", "meanSeaLevelMillibars").dbl() ?: 1013.0,
            visibilityKm = c.at("visibility", "distance").dbl(),
            uv = c.at("uvIndex").dbl(),
            cloud = c.at("cloudCover").dbl()?.toInt(),
            rainChance = c.at("precipitation", "probability", "percent").dbl()?.toInt()
        )

        val hourly = hourItems.mapNotNull { h ->
            val time = loc(h.at("interval", "startTime").str()) ?: return@mapNotNull null
            val temp = h.at("temperature", "degrees").dbl() ?: return@mapNotNull null
            HourW(
                time = time,
                tempC = temp,
                rainChance = h.at("precipitation", "probability", "percent").dbl()?.toInt() ?: 0,
                code = code(h.at("weatherCondition", "type").str()),
                isDay = h.at("isDaytime").bool() ?: true,
                windKmh = h.at("wind", "speed", "value").dbl()
            )
        }

        val daily = ((d["forecastDays"] as? JsonArray) ?: JsonArray(emptyList())).mapNotNull { x ->
            val y = x.at("displayDate", "year").dbl()?.toInt() ?: return@mapNotNull null
            val m = x.at("displayDate", "month").dbl()?.toInt() ?: return@mapNotNull null
            val dd = x.at("displayDate", "day").dbl()?.toInt() ?: return@mapNotNull null
            val max = x.at("maxTemperature", "degrees").dbl() ?: return@mapNotNull null
            val min = x.at("minTemperature", "degrees").dbl() ?: return@mapNotNull null
            DayW(
                date = "%04d-%02d-%02d".format(y, m, dd),
                code = code(x.at("daytimeForecast", "weatherCondition", "type").str()),
                maxC = max,
                minC = min,
                sunrise = loc(x.at("sunEvents", "sunriseTime").str()),
                sunset = loc(x.at("sunEvents", "sunsetTime").str()),
                uvMax = x.at("daytimeForecast", "uvIndex").dbl(),
                rainChance = x.at("daytimeForecast", "precipitation", "probability", "percent").dbl()?.toInt(),
                rainMm = x.at("daytimeForecast", "precipitation", "qpf", "quantity").dbl()
            )
        }

        val alertTitles = ((alerts.await()?.get("weatherAlerts") as? JsonArray) ?: JsonArray(emptyList()))
            .mapNotNull { it.at("alertTitle", "text").str() }

        Repo.finalize(
            WeatherBundle(
                source = "google",
                fetchedAt = System.currentTimeMillis(),
                timezone = tz,
                current = current,
                hourly = hourly,
                daily = daily,
                air = air.await(),
                alerts = alertTitles
            )
        )
    }
}
