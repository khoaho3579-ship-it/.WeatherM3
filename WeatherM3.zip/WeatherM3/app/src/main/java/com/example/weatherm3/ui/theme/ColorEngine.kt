package com.example.weatherm3.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import com.google.android.material.color.utilities.Hct
import com.google.android.material.color.utilities.TonalPalette

private class Pal(
    val p: TonalPalette,
    val s: TonalPalette,
    val t: TonalPalette,
    val n: TonalPalette,
    val nv: TonalPalette
)

private fun rot(h: Double, d: Double): Double {
    var x = (h + d) % 360.0
    if (x < 0) x += 360.0
    return x
}

private fun tp(hue: Double, chroma: Double): TonalPalette = TonalPalette.of(rot(hue, 0.0), chroma)

private fun palettes(seed: Int, style: String): Pal {
    val hct = Hct.fromInt(seed)
    val h = hct.hue
    val c = hct.chroma
    return when (style) {
        "vibrant" -> Pal(tp(h, 200.0), tp(h + 30, 24.0), tp(h + 60, 32.0), tp(h, 10.0), tp(h, 12.0))
        "expressive" -> Pal(tp(h + 240, 40.0), tp(h + 15, 24.0), tp(h + 120, 32.0), tp(h + 15, 8.0), tp(h + 15, 12.0))
        "neutral" -> Pal(tp(h, 12.0), tp(h, 8.0), tp(h + 60, 16.0), tp(h, 2.0), tp(h, 2.0))
        "mono" -> Pal(tp(h, 0.0), tp(h, 0.0), tp(h, 0.0), tp(h, 0.0), tp(h, 0.0))
        "fidelity" -> Pal(
            tp(h, c), tp(h, maxOf(c - 32.0, c * 0.5)), tp(h + 60, maxOf(c * 0.7, 16.0)),
            tp(h, c / 8.0 + 4.0), tp(h, c / 8.0 + 8.0)
        )
        else -> Pal(tp(h, 36.0), tp(h, 16.0), tp(h + 60, 24.0), tp(h, 6.0), tp(h, 8.0))
    }
}

/**
 * Sinh bảng màu M3 từ "seed color" bằng TonalPalette (HCT) của thư viện material-color-utilities.
 * Ánh xạ tông (tone) theo đặc tả M3; mức tương phản 0/1/2 = chuẩn/trung bình/cao.
 */
fun seedColorScheme(seed: Int, dark: Boolean, style: String, contrast: Int): ColorScheme {
    val pal = palettes(seed, style)
    val err = TonalPalette.of(25.0, 84.0)
    val k = contrast.coerceIn(0, 2)
    fun c(p: TonalPalette, tone: Int) = Color(p.tone(tone))

    return if (!dark) {
        val acc = intArrayOf(40, 30, 20)[k]
        val cont = intArrayOf(90, 88, 85)[k]
        val onCont = intArrayOf(10, 5, 0)[k]
        val osv = intArrayOf(30, 20, 10)[k]
        val ol = intArrayOf(50, 35, 20)[k]
        val olv = intArrayOf(80, 60, 45)[k]
        lightColorScheme(
            primary = c(pal.p, acc), onPrimary = c(pal.p, 100),
            primaryContainer = c(pal.p, cont), onPrimaryContainer = c(pal.p, onCont),
            inversePrimary = c(pal.p, 80),
            secondary = c(pal.s, acc), onSecondary = c(pal.s, 100),
            secondaryContainer = c(pal.s, cont), onSecondaryContainer = c(pal.s, onCont),
            tertiary = c(pal.t, acc), onTertiary = c(pal.t, 100),
            tertiaryContainer = c(pal.t, cont), onTertiaryContainer = c(pal.t, onCont),
            background = c(pal.n, 98), onBackground = c(pal.n, 10),
            surface = c(pal.n, 98), onSurface = c(pal.n, 10),
            surfaceVariant = c(pal.nv, 90), onSurfaceVariant = c(pal.nv, osv),
            surfaceTint = c(pal.p, acc),
            inverseSurface = c(pal.n, 20), inverseOnSurface = c(pal.n, 95),
            error = c(err, acc), onError = c(err, 100),
            errorContainer = c(err, cont), onErrorContainer = c(err, onCont),
            outline = c(pal.nv, ol), outlineVariant = c(pal.nv, olv),
            scrim = Color.Black,
            surfaceBright = c(pal.n, 98), surfaceDim = c(pal.n, 87),
            surfaceContainerLowest = c(pal.n, 100), surfaceContainerLow = c(pal.n, 96),
            surfaceContainer = c(pal.n, 94), surfaceContainerHigh = c(pal.n, 92),
            surfaceContainerHighest = c(pal.n, 90)
        )
    } else {
        val acc = intArrayOf(80, 85, 95)[k]
        val onAcc = intArrayOf(20, 15, 10)[k]
        val cont = intArrayOf(30, 25, 20)[k]
        val onCont = intArrayOf(90, 95, 100)[k]
        val osv = intArrayOf(80, 88, 95)[k]
        val ol = intArrayOf(60, 75, 90)[k]
        val olv = intArrayOf(30, 45, 70)[k]
        darkColorScheme(
            primary = c(pal.p, acc), onPrimary = c(pal.p, onAcc),
            primaryContainer = c(pal.p, cont), onPrimaryContainer = c(pal.p, onCont),
            inversePrimary = c(pal.p, 40),
            secondary = c(pal.s, acc), onSecondary = c(pal.s, onAcc),
            secondaryContainer = c(pal.s, cont), onSecondaryContainer = c(pal.s, onCont),
            tertiary = c(pal.t, acc), onTertiary = c(pal.t, onAcc),
            tertiaryContainer = c(pal.t, cont), onTertiaryContainer = c(pal.t, onCont),
            background = c(pal.n, 6), onBackground = c(pal.n, 90),
            surface = c(pal.n, 6), onSurface = c(pal.n, 90),
            surfaceVariant = c(pal.nv, 30), onSurfaceVariant = c(pal.nv, osv),
            surfaceTint = c(pal.p, acc),
            inverseSurface = c(pal.n, 90), inverseOnSurface = c(pal.n, 20),
            error = c(err, acc), onError = c(err, onAcc),
            errorContainer = c(err, cont), onErrorContainer = c(err, onCont),
            outline = c(pal.nv, ol), outlineVariant = c(pal.nv, olv),
            scrim = Color.Black,
            surfaceBright = c(pal.n, 24), surfaceDim = c(pal.n, 6),
            surfaceContainerLowest = c(pal.n, 4), surfaceContainerLow = c(pal.n, 10),
            surfaceContainer = c(pal.n, 12), surfaceContainerHigh = c(pal.n, 17),
            surfaceContainerHighest = c(pal.n, 22)
        )
    }
}

/** Bảng màu seed gợi ý (≥ 16 màu). */
val SEED_COLORS: List<Int> = listOf(
    0xFF435D91, 0xFF1565C0, 0xFF0097A7, 0xFF00796B, 0xFF2E7D32, 0xFF7CB342,
    0xFFF9A825, 0xFFEF6C00, 0xFFD84315, 0xFFC62828, 0xFFAD1457, 0xFF8E24AA,
    0xFF5E35B1, 0xFF3949AB, 0xFF6D4C41, 0xFF546E7A, 0xFF00ACC1, 0xFFE91E63
).map { it.toInt() }

/** Lấy màu chủ đạo từ ảnh: chia 12 nhóm theo sắc độ, nhóm nào nhiều điểm ảnh "đậm màu" nhất thì thắng. */
fun dominantColor(pixels: IntArray): Int {
    val sum = Array(12) { LongArray(4) } // r, g, b, weight
    val hsv = FloatArray(3)
    for (px in pixels) {
        android.graphics.Color.colorToHSV(px, hsv)
        if (hsv[1] < 0.25f || hsv[2] < 0.2f) continue
        val bucket = ((hsv[0] / 30f).toInt()).coerceIn(0, 11)
        val w = (hsv[1] * 100).toLong() + 1
        sum[bucket][0] += android.graphics.Color.red(px) * w
        sum[bucket][1] += android.graphics.Color.green(px) * w
        sum[bucket][2] += android.graphics.Color.blue(px) * w
        sum[bucket][3] += w
    }
    val best = sum.maxByOrNull { it[3] } ?: return 0xFF435D91.toInt()
    if (best[3] == 0L) return 0xFF435D91.toInt()
    return android.graphics.Color.rgb(
        (best[0] / best[3]).toInt(), (best[1] / best[3]).toInt(), (best[2] / best[3]).toInt()
    )
}
