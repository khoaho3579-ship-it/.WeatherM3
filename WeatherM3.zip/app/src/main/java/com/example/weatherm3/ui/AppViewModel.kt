package com.example.weatherm3.ui

import android.app.Application
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.weatherm3.core.L
import com.example.weatherm3.core.resolveLang
import com.example.weatherm3.data.AppJson
import com.example.weatherm3.data.AppSettings
import com.example.weatherm3.data.DEFAULT_PLACE
import com.example.weatherm3.data.GeoResult
import com.example.weatherm3.data.LocationHelper
import com.example.weatherm3.data.Place
import com.example.weatherm3.data.Repo
import com.example.weatherm3.data.Secret
import com.example.weatherm3.data.SettingsRepository
import com.example.weatherm3.data.WeatherBundle
import com.example.weatherm3.data.WeatherCache
import com.example.weatherm3.widget.WeatherWidget
import com.example.weatherm3.work.Notifier
import com.example.weatherm3.work.Scheduler
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.distinctUntilChangedBy
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.IOException

data class WeatherUi(
    val bundle: WeatherBundle? = null,
    val loading: Boolean = false,
    val error: String? = null,
    val stale: Boolean = false
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val repo = SettingsRepository(ctx)

    val ready = MutableStateFlow(false)
    val settings = MutableStateFlow(AppSettings())
    val ui = MutableStateFlow(WeatherUi())
    val searchResults = MutableStateFlow<List<GeoResult>>(emptyList())
    val searching = MutableStateFlow(false)
    val message = MutableStateFlow<String?>(null)

    private var job: Job? = null
    private var shownKey: String? = null
    private val pretty = Json { prettyPrint = true; encodeDefaults = true }

    private fun l(): L = L(resolveLang(settings.value.language))

    init {
        viewModelScope.launch {
            repo.flow.collect {
                settings.value = it
                ready.value = true
            }
        }
        // Tải lại khi đổi địa điểm / nguồn dữ liệu / API key
        viewModelScope.launch {
            repo.flow
                .map { Triple(it.activePlace().lat to it.activePlace().lon, it.source, it.googleKeyVersion) }
                .distinctUntilChanged()
                .collect { refresh(true) }
        }
        // Lên lịch cập nhật nền / thông báo hằng ngày
        viewModelScope.launch {
            repo.flow
                .distinctUntilChangedBy { listOf(it.refreshMinutes, it.wifiOnly, it.dailyOn, it.dailyHour, it.dailyMinute) }
                .collect { Scheduler.apply(ctx, it) }
        }
        // Thông báo cố định
        viewModelScope.launch {
            repo.flow.distinctUntilChangedBy { it.ongoingOn }.collect { s ->
                ui.value.bundle?.let { Notifier.ongoing(ctx, it, s) }
            }
        }
    }

    private fun friendly(e: Exception, l: L): String = when (e) {
        is IOException -> l.t("Không thể tải dữ liệu. Kiểm tra kết nối mạng.", "Can't load data. Check your connection.")
        else -> e.message ?: l.t("Lỗi không xác định", "Unknown error")
    }

    fun refresh(force: Boolean = true) {
        job?.cancel()
        job = viewModelScope.launch {
            val s = repo.current()
            val place = s.activePlace()
            val lang = resolveLang(s.language)
            val key = WeatherCache.key(place, s.source)
            if (key != shownKey) {
                ui.value = WeatherUi(loading = true)
                shownKey = key
            } else {
                ui.update { it.copy(loading = true, error = null) }
            }
            val cached = withContext(Dispatchers.IO) { Repo.cached(ctx, place, s) }
            if (cached != null && ui.value.bundle == null) {
                ui.update { it.copy(bundle = cached, stale = true) }
            }
            try {
                val r = Repo.load(ctx, place, s, lang, force)
                ui.value = WeatherUi(r.bundle, false, null, r.stale)
                WeatherWidget().updateAll(ctx)
                if (s.ongoingOn) Notifier.ongoing(ctx, r.bundle, s)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ui.update { it.copy(loading = false, error = friendly(e, L(lang))) }
            }
        }
    }

    fun updateSettings(t: (AppSettings) -> AppSettings) {
        viewModelScope.launch { repo.update(t) }
    }

    // ----- Địa điểm -----
    fun setActive(id: String) = updateSettings { it.copy(activeId = id) }

    fun search(q: String) {
        if (q.trim().length < 2) {
            searchResults.value = emptyList()
            return
        }
        viewModelScope.launch {
            searching.value = true
            searchResults.value = try {
                Repo.search(q.trim(), resolveLang(settings.value.language))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
            searching.value = false
        }
    }

    fun clearSearch() {
        searchResults.value = emptyList()
    }

    fun addPlace(g: GeoResult) {
        val p = Place(
            id = "p_" + System.currentTimeMillis(),
            name = g.name,
            lat = g.latitude,
            lon = g.longitude,
            sub = listOfNotNull(g.admin1, g.country.ifBlank { null }).joinToString(", ")
        )
        updateSettings { it.copy(places = it.places + p, activeId = p.id) }
    }

    fun removePlace(id: String) = updateSettings { s ->
        val left = s.places.filter { it.id != id }
        if (left.isEmpty()) s.copy(places = listOf(DEFAULT_PLACE), activeId = DEFAULT_PLACE.id)
        else s.copy(places = left, activeId = if (s.activeId == id) left.first().id else s.activeId)
    }

    fun movePlace(id: String, delta: Int) = updateSettings { s ->
        val list = s.places.toMutableList()
        val i = list.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= list.size) s
        else {
            val x = list.removeAt(i)
            list.add(j, x)
            s.copy(places = list)
        }
    }

    fun useGps() {
        viewModelScope.launch {
            val lang = resolveLang(settings.value.language)
            val loc = LocationHelper.current(ctx)
            if (loc == null) {
                message.value = L(lang).t("Không lấy được vị trí. Hãy bật GPS/Định vị.", "Couldn't get location. Turn on location services.")
                return@launch
            }
            val name = LocationHelper.placeName(ctx, loc.latitude, loc.longitude, lang)
                ?: L(lang).t("Vị trí hiện tại", "Current location")
            val p = Place("gps", name, loc.latitude, loc.longitude, gps = true)
            updateSettings { s -> s.copy(places = s.places.filter { it.id != "gps" } + p, activeId = "gps") }
        }
    }

    fun notifyMessage(vi: String, en: String) {
        message.value = l().t(vi, en)
    }

    fun clearMessage() {
        message.value = null
    }

    // ----- Dữ liệu / bảo mật -----
    fun saveGoogleKey(key: String) {
        Secret.saveGoogleKey(ctx, key)
        updateSettings { it.copy(googleKeyVersion = it.googleKeyVersion + 1) }
        notifyMessage("Đã lưu API key (mã hóa trên máy)", "API key saved (encrypted on device)")
    }

    fun hasGoogleKey(): Boolean = Secret.googleKey(ctx) != null

    fun clearCache() {
        WeatherCache.clear(ctx)
        notifyMessage("Đã xóa bộ nhớ đệm", "Cache cleared")
    }

    fun clearPlaceHistory() {
        updateSettings { it.copy(places = listOf(DEFAULT_PLACE), activeId = DEFAULT_PLACE.id) }
        notifyMessage("Đã xóa danh sách địa điểm", "Saved places cleared")
    }

    // ----- Sao lưu / khôi phục -----
    fun exportJson(): String = pretty.encodeToString(settings.value)

    fun importJson(text: String) {
        try {
            val s = AppJson.decodeFromString<AppSettings>(text)
            updateSettings { cur -> s.copy(googleKeyVersion = cur.googleKeyVersion) }
            notifyMessage("Đã khôi phục cài đặt", "Settings restored")
        } catch (e: Exception) {
            notifyMessage("File không hợp lệ", "Invalid file")
        }
    }
}
