package com.example.weatherm3.ui.theme

import android.graphics.Typeface
import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.weatherm3.core.L
import com.example.weatherm3.core.LocalL
import com.example.weatherm3.core.resolveLang
import com.example.weatherm3.data.AppSettings

val LocalAppSettings = compositionLocalOf { AppSettings() }
/** "expressive" | "standard" | "off" */
val LocalMotion = compositionLocalOf { "expressive" }

val FONT_KEYS = listOf("default", "sans", "condensed", "serif", "mono", "casual", "cursive")

private val familyCache = HashMap<String, FontFamily>()

fun fontFamilyFor(key: String): FontFamily = familyCache.getOrPut(key) { buildFamily(key) }

private fun buildFamily(key: String): FontFamily = when (key) {
    "sans" -> FontFamily.SansSerif
    "serif" -> FontFamily.Serif
    "mono" -> FontFamily.Monospace
    "cursive" -> FontFamily.Cursive
    "condensed" -> FontFamily(Typeface.create("sans-serif-condensed", Typeface.NORMAL))
    "casual" -> FontFamily(Typeface.create("casual", Typeface.NORMAL))
    else -> FontFamily.Default
}

/**
 * Typography KHÔNG còn nhân fontScale (việc đó do LocalDensity.fontScale xử lý, xem WeatherTheme),
 * nên tránh được lỗi cộng dồn hệ thống × app. Độ đậm bị chặn trong 300..700 vì các phông hệ
 * thống không có trục weight liên tục (100/900 sẽ bị giả lập và đổi bề rộng chữ).
 */
fun buildTypography(s: AppSettings): Typography {
    val family = fontFamilyFor(s.font)
    val shift = when (s.fontWeight) { 0 -> -100; 2 -> 100; else -> 0 }
    val emph = if (s.emphasized) 100 else 0
    val lineStyle = LineHeightStyle(alignment = LineHeightStyle.Alignment.Center, trim = LineHeightStyle.Trim.None)
    fun TextStyle.adj(extra: Int = 0): TextStyle {
        val w = ((fontWeight ?: FontWeight.Normal).weight + shift + extra).coerceIn(300, 700)
        return copy(fontFamily = family, fontWeight = FontWeight(w), lineHeightStyle = lineStyle)
    }
    val b = Typography()
    return Typography(
        displayLarge = b.displayLarge.adj(), displayMedium = b.displayMedium.adj(), displaySmall = b.displaySmall.adj(),
        headlineLarge = b.headlineLarge.adj(emph), headlineMedium = b.headlineMedium.adj(emph), headlineSmall = b.headlineSmall.adj(emph),
        titleLarge = b.titleLarge.adj(emph), titleMedium = b.titleMedium.adj(emph), titleSmall = b.titleSmall.adj(emph),
        bodyLarge = b.bodyLarge.adj(), bodyMedium = b.bodyMedium.adj(), bodySmall = b.bodySmall.adj(),
        labelLarge = b.labelLarge.adj(emph), labelMedium = b.labelMedium.adj(emph), labelSmall = b.labelSmall.adj(emph)
    )
}

fun buildShapes(style: String): Shapes {
    val f = when (style) { "square" -> 0.3f; "round" -> 1.4f; "max" -> 2f; else -> 1f }
    fun r(v: Float) = RoundedCornerShape((v * f).dp)
    return Shapes(extraSmall = r(4f), small = r(8f), medium = r(12f), large = r(16f), extraLarge = r(28f))
}

private fun lerpScheme(a: ColorScheme, b: ColorScheme, t: Float): ColorScheme {
    fun m(x: Color, y: Color) = lerp(x, y, t)
    return b.copy(
        primary = m(a.primary, b.primary), onPrimary = m(a.onPrimary, b.onPrimary),
        primaryContainer = m(a.primaryContainer, b.primaryContainer), onPrimaryContainer = m(a.onPrimaryContainer, b.onPrimaryContainer),
        inversePrimary = m(a.inversePrimary, b.inversePrimary),
        secondary = m(a.secondary, b.secondary), onSecondary = m(a.onSecondary, b.onSecondary),
        secondaryContainer = m(a.secondaryContainer, b.secondaryContainer), onSecondaryContainer = m(a.onSecondaryContainer, b.onSecondaryContainer),
        tertiary = m(a.tertiary, b.tertiary), onTertiary = m(a.onTertiary, b.onTertiary),
        tertiaryContainer = m(a.tertiaryContainer, b.tertiaryContainer), onTertiaryContainer = m(a.onTertiaryContainer, b.onTertiaryContainer),
        background = m(a.background, b.background), onBackground = m(a.onBackground, b.onBackground),
        surface = m(a.surface, b.surface), onSurface = m(a.onSurface, b.onSurface),
        surfaceVariant = m(a.surfaceVariant, b.surfaceVariant), onSurfaceVariant = m(a.onSurfaceVariant, b.onSurfaceVariant),
        surfaceTint = m(a.surfaceTint, b.surfaceTint),
        inverseSurface = m(a.inverseSurface, b.inverseSurface), inverseOnSurface = m(a.inverseOnSurface, b.inverseOnSurface),
        error = m(a.error, b.error), onError = m(a.onError, b.onError),
        errorContainer = m(a.errorContainer, b.errorContainer), onErrorContainer = m(a.onErrorContainer, b.onErrorContainer),
        outline = m(a.outline, b.outline), outlineVariant = m(a.outlineVariant, b.outlineVariant),
        surfaceBright = m(a.surfaceBright, b.surfaceBright), surfaceDim = m(a.surfaceDim, b.surfaceDim),
        surfaceContainerLowest = m(a.surfaceContainerLowest, b.surfaceContainerLowest),
        surfaceContainerLow = m(a.surfaceContainerLow, b.surfaceContainerLow),
        surfaceContainer = m(a.surfaceContainer, b.surfaceContainer),
        surfaceContainerHigh = m(a.surfaceContainerHigh, b.surfaceContainerHigh),
        surfaceContainerHighest = m(a.surfaceContainerHighest, b.surfaceContainerHighest)
    )
}

/**
 * Chuyển màu bằng MỘT Animatable duy nhất (thay cho 35 animateColorAsState). Chỉ chạy ~320ms
 * khi bảng màu đích đổi; ngoài lúc đó trả về đúng đối tượng đích (không tính toán gì thêm).
 */
@Composable
private fun rememberAnimatedScheme(target: ColorScheme, enabled: Boolean): ColorScheme {
    if (!enabled) return target
    var from by remember { mutableStateOf(target) }
    var to by remember { mutableStateOf(target) }
    val progress = remember { Animatable(1f) }
    LaunchedEffect(target) {
        if (target === to) return@LaunchedEffect
        from = lerpScheme(from, to, progress.value)
        to = target
        progress.snapTo(0f)
        progress.animateTo(1f, tween(320, easing = FastOutSlowInEasing))
    }
    val p = progress.value
    return if (p >= 1f) to else lerpScheme(from, to, p)
}

fun isDarkFor(s: AppSettings, system: Boolean): Boolean = when (s.theme) {
    "dark", "amoled" -> true
    "light" -> false
    else -> system
}

@Composable
fun WeatherTheme(s: AppSettings, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = isDarkFor(s, isSystemInDarkTheme())
    val dynamic = s.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val amoled = dark && s.theme == "amoled"

    // Tính 1 lần cho mỗi tổ hợp tham số thật sự ảnh hưởng (trước đây tính lại mỗi lần recomposition).
    val scheme = remember(dynamic, dark, amoled, s.seed, s.paletteStyle, s.contrast) {
        var sc: ColorScheme =
            if (dynamic) { if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx) }
            else seedColorScheme(s.seed, dark, s.paletteStyle, s.contrast)
        if (amoled) {
            sc = sc.copy(
                background = Color.Black, surface = Color.Black, surfaceDim = Color.Black,
                surfaceContainerLowest = Color.Black, surfaceContainerLow = Color(0xFF0B0B0B),
                surfaceContainer = Color(0xFF121212), surfaceContainerHigh = Color(0xFF1A1A1A),
                surfaceContainerHighest = Color(0xFF222222)
            )
        }
        sc
    }
    val animatedScheme = rememberAnimatedScheme(scheme, s.motion != "off")
    val typography = remember(s.font, s.fontWeight, s.emphasized) { buildTypography(s) }
    val shapes = remember(s.corners) { buildShapes(s.corners) }
    val lang = remember(s.language) { L(resolveLang(s.language)) }

    // Cỡ chữ: hệ số của app nhân với hệ số hệ thống MỘT lần, rồi chặn theo giới hạn người dùng chọn.
    val base = LocalDensity.current
    val effScale = remember(base.fontScale, s.fontScale, s.fontCap, s.overflowTest) {
        if (s.overflowTest) 2f else {
            var e = base.fontScale * s.fontScale.coerceIn(0.8f, 1.5f)
            if (s.fontCap > 0) e = e.coerceAtMost(s.fontCap / 100f)
            e
        }
    }
    val density = remember(base.density, effScale) { Density(base.density, effScale) }

    CompositionLocalProvider(
        LocalDensity provides density,
        LocalAppSettings provides s,
        LocalMotion provides s.motion,
        LocalL provides lang
    ) {
        ExpressiveTheme(
            colorScheme = animatedScheme,
            motion = s.motion,
            shapes = shapes,
            typography = typography,
            content = content
        )
    }
}
