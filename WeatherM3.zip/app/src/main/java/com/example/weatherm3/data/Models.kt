package com.example.weatherm3.data

import androidx.compose.runtime.Immutable
import kotlinx.serialization.Serializable

@Immutable
@Serializable
data class Place(
    val id: String,
    val name: String,
    val lat: Double,
    val lon: Double,
    val sub: String = "",
    val gps: Boolean = false
)

val DEFAULT_PLACE = Place("default", "Đắk Song", 12.0, 107.6)

@Immutable
@Serializable
data class CurrentW(
    val time: String,
    val tempC: Double,
    val feelsC: Double,
    val humidity: Int,
    val code: Int,
    val isDay: Boolean,
    val windKmh: Double,
    val windDir: Int,
    val pressure: Double,
    val visibilityKm: Double? = null,
    val uv: Double? = null,
    val cloud: Int? = null,
    val rainChance: Int? = null
)

@Immutable
@Serializable
data class HourW(
    val time: String,
    val tempC: Double,
    val rainChance: Int,
    val code: Int,
    val isDay: Boolean = true,
    val windKmh: Double? = null
)

@Immutable
@Serializable
data class DayW(
    val date: String,
    val code: Int,
    val maxC: Double,
    val minC: Double,
    val sunrise: String? = null,
    val sunset: String? = null,
    val uvMax: Double? = null,
    val rainChance: Int? = null,
    val rainMm: Double? = null
)

@Immutable
@Serializable
data class AirW(
    val usAqi: Int,
    val pm25: Double? = null,
    val pm10: Double? = null,
    val o3: Double? = null,
    val no2: Double? = null
)

@Immutable
@Serializable
data class WeatherBundle(
    val source: String,
    val fetchedAt: Long,
    val timezone: String,
    val current: CurrentW,
    val hourly: List<HourW>,
    val daily: List<DayW>,
    val air: AirW? = null,
    val alerts: List<String> = emptyList()
)
