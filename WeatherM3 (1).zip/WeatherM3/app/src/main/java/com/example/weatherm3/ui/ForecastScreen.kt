@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.weatherm3.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.weatherm3.core.Fmt
import com.example.weatherm3.core.LocalL
import com.example.weatherm3.core.describe
import com.example.weatherm3.core.skyOf
import com.example.weatherm3.data.AppSettings
import com.example.weatherm3.data.HourW
import com.example.weatherm3.ui.components.Card28
import com.example.weatherm3.ui.components.WeatherGlyph
import com.example.weatherm3.ui.components.AppLoadingCenter

@Composable
fun ForecastScreen(vm: AppViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val l = LocalL.current
    var mode by rememberSaveable { mutableIntStateOf(0) }
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    val bg = MaterialTheme.colorScheme.background

    Scaffold(
        modifier = Modifier.nestedScroll(scroll.nestedScrollConnection),
        containerColor = bg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            LargeTopAppBar(
                title = { Text(l.t("Dự báo", "Forecast")) },
                scrollBehavior = scroll,
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = bg,
                    scrolledContainerColor = MaterialTheme.colorScheme.surfaceContainer
                )
            )
        }
    ) { pad ->
        val b = ui.bundle
        if (b == null) {
            AppLoadingCenter(Modifier.padding(pad).fillMaxSize())
        } else {
            LazyColumn(
                Modifier.padding(pad).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        listOf(l.t("Theo giờ", "Hourly"), l.t("Theo ngày", "Daily")).forEachIndexed { i, label ->
                            SegmentedButton(
                                selected = mode == i,
                                onClick = { mode = i },
                                shape = SegmentedButtonDefaults.itemShape(i, 2)
                            ) { Text(label) }
                        }
                    }
                }
                if (mode == 0) {
                    item { TempChart(b.hourly.take(24), s) }
                    items(b.hourly.take(48)) { h ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(MaterialTheme.shapes.large)
                                .background(MaterialTheme.colorScheme.surfaceContainer)
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(Fmt.dateTimeLong(h.time, s, l), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            WeatherGlyph(skyOf(h.code), h.isDay, false, Modifier.size(30.dp))
                            Text(Fmt.temp(h.tempC, s), Modifier.width(52.dp).padding(start = 8.dp), style = MaterialTheme.typography.titleMedium)
                            Text("${h.rainChance}%", Modifier.width(44.dp), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                } else {
                    items(b.daily.size) { i ->
                        val d = b.daily[i]
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(MaterialTheme.shapes.large)
                                .background(MaterialTheme.colorScheme.surfaceContainer)
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            WeatherGlyph(skyOf(d.code), true, false, Modifier.size(40.dp))
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text(Fmt.dayName(d.date, i, l) + " · " + Fmt.dayShort(d.date), style = MaterialTheme.typography.titleSmall)
                                Text(describe(d.code, l), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    l.t("Mưa ", "Rain ") + (d.rainChance?.let { "$it%" } ?: "--") +
                                        (d.rainMm?.let { " · " + Fmt.rain(it, s) } ?: "") +
                                        " · ☀ " + Fmt.clock(d.sunrise, s, l) + " – " + Fmt.clock(d.sunset, s, l),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(Fmt.temp(d.maxC, s), style = MaterialTheme.typography.titleMedium)
                                Text(Fmt.temp(d.minC, s), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TempChart(hours: List<HourW>, s: AppSettings) {
    if (hours.size < 2) return
    val line = MaterialTheme.colorScheme.primary
    val fill = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
    val min = hours.minOf { it.tempC }
    val max = hours.maxOf { it.tempC }
    val span = (max - min).coerceAtLeast(1.0)
    Card28(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth()) {
                Text(Fmt.temp(max, s), Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
                Text(Fmt.temp(min, s), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Canvas(Modifier.fillMaxWidth().height(120.dp).padding(vertical = 8.dp)) {
                val stepX = size.width / (hours.size - 1)
                fun y(t: Double) = (size.height - ((t - min) / span).toFloat() * size.height)
                val path = Path()
                val area = Path()
                hours.forEachIndexed { i, h ->
                    val x = stepX * i
                    if (i == 0) { path.moveTo(x, y(h.tempC)); area.moveTo(x, size.height); area.lineTo(x, y(h.tempC)) }
                    else { path.lineTo(x, y(h.tempC)); area.lineTo(x, y(h.tempC)) }
                }
                area.lineTo(size.width, size.height)
                area.close()
                drawPath(area, fill)
                drawPath(path, line, style = Stroke(5f, cap = StrokeCap.Round))
                drawCircle(line, 8f, Offset(0f, y(hours.first().tempC)))
            }
        }
    }
}
