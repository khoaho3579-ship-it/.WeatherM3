package com.example.weatherm3.work

import android.content.Context
import androidx.glance.appwidget.updateAll
import androidx.work.CoroutineWorker
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.weatherm3.data.AppSettings
import com.example.weatherm3.data.Repo
import com.example.weatherm3.data.SettingsRepository
import com.example.weatherm3.widget.WeatherWidget
import java.time.Duration
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

class RefreshWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext
        val s = SettingsRepository(app).current()
        return try {
            val r = Repo.load(app, s.activePlace(), s, Notifier.lang(s).lang, force = true)
            WeatherWidget().updateAll(app)
            if (s.alertsOn) Notifier.alerts(app, r.bundle, s)
            Notifier.ongoing(app, r.bundle, s)
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            if (runAttemptCount >= 3) Result.success() else Result.retry()
        }
    }
}

class DailyWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext
        val s = SettingsRepository(app).current()
        if (!s.dailyOn) return Result.success()
        try {
            val r = Repo.load(app, s.activePlace(), s, Notifier.lang(s).lang, force = true)
            Notifier.daily(app, r.bundle, s)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
        }
        Scheduler.scheduleDaily(app, s) // hẹn lại cho ngày mai
        return Result.success()
    }
}

object Scheduler {
    private const val REFRESH = "weather-refresh"
    private const val DAILY = "daily-forecast"

    fun apply(ctx: Context, s: AppSettings) {
        val wm = WorkManager.getInstance(ctx)
        val net = if (s.wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED
        val req = PeriodicWorkRequestBuilder<RefreshWorker>(s.refreshMinutes.coerceAtLeast(15).toLong(), TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(net).build())
            .build()
        wm.enqueueUniquePeriodicWork(REFRESH, ExistingPeriodicWorkPolicy.UPDATE, req)
        if (s.dailyOn) scheduleDaily(ctx, s) else wm.cancelUniqueWork(DAILY)
    }

    fun scheduleDaily(ctx: Context, s: AppSettings) {
        val now = LocalDateTime.now()
        var next = now.withHour(s.dailyHour).withMinute(s.dailyMinute).withSecond(0).withNano(0)
        if (!next.isAfter(now.plusMinutes(1))) next = next.plusDays(1)
        val delay = Duration.between(now, next).toMillis()
        val req = OneTimeWorkRequestBuilder<DailyWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(DAILY, ExistingWorkPolicy.REPLACE, req)
    }
}
