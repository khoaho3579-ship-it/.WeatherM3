@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.example.weatherm3.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.weatherm3.core.Fmt
import com.example.weatherm3.core.Insights
import com.example.weatherm3.core.L
import com.example.weatherm3.core.LocalL
import com.example.weatherm3.core.Sky
import com.example.weatherm3.core.aqiLabel
import com.example.weatherm3.core.compass
import com.example.weatherm3.core.describe
import com.example.weatherm3.core.skyOf
import com.example.weatherm3.core.uvLabel
import com.example.weatherm3.data.AppSettings
import com.example.weatherm3.data.DayW
import com.example.weatherm3.data.Place
import com.example.weatherm3.data.WeatherBundle
import com.example.weatherm3.ui.components.Appear
import com.example.weatherm3.ui.components.Card28
import com.example.weatherm3.ui.components.SectionTitle
import com.example.weatherm3.ui.components.WeatherBackdrop
import com.example.weatherm3.ui.components.WeatherGlyph
import com.example.weatherm3.ui.theme.AppLoadingIndicator
import com.example.weatherm3.ui.theme.LocalMotion
import com.example.weatherm3.ui.theme.iconShape
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private fun animOn(s: AppSettings, motion: String) = s.weatherAnim && !s.batterySaver && motion != "off"

@Composable
fun TodayScreen(vm: AppViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val l = LocalL.current
    val motion = LocalMotion.current
    val place = s.activePlace()
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    val bg = MaterialTheme.colorScheme.background

    Scaffold(
        modifier = Modifier.nestedScroll(scroll.nestedScrollConnection),
        containerColor = bg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            LargeTopAppBar(
                title = { Text(place.name) },
                scrollBehavior = scroll,
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = bg,
                    scrolledContainerColor = MaterialTheme.colorScheme.surfaceContainer
                ),
                actions = {
                    IconButton(onClick = { vm.refresh(true) }) {
                        Icon(Icons.Rounded.Refresh, contentDescription = l.t("Làm mới", "Refresh"))
                    }
                }
            )
        }
    ) { pad ->
        PullToRefreshBox(
            isRefreshing = ui.loading && ui.bundle != null,
            onRefresh = { vm.refresh(true) },
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
        ) {
            val b = ui.bundle
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (b == null) {
                    item {
                        Box(Modifier.fillMaxWidth().height(320.dp), contentAlignment = Alignment.Center) {
                            if (ui.loading) {
                                AppLoadingIndicator(Modifier.size(72.dp))
                            } else {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Icon(Icons.Rounded.CloudOff, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
                                    Text(ui.error ?: l.t("Chưa có dữ liệu", "No data yet"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Button(onClick = { vm.refresh(true) }) { Text(l.t("Thử lại", "Retry")) }
                                }
                            }
                        }
                    }
                } else {
                    item { Appear(0) { HeaderCard(b, s, l, place, animOn(s, motion), motion) } }
                    if (ui.stale || ui.error != null) {
                        item {
                            Appear(1) {
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(MaterialTheme.shapes.large)
                                        .background(MaterialTheme.colorScheme.secondaryContainer)
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Rounded.CloudOff, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                                    Spacer(Modifier.width(12.dp))
                                    Text(
                                        ui.error ?: l.t("Đang hiển thị dữ liệu đã lưu (ngoại tuyến).", "Showing saved data (offline)."),
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                    }
                    val alerts = Insights.alerts(b, l)
                    if (alerts.isNotEmpty()) {
                        item {
                            Appear(1) {
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(MaterialTheme.shapes.extraLarge)
                                        .background(MaterialTheme.colorScheme.errorContainer)
                                        .padding(18.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Icon(Icons.Rounded.Warning, null, tint = MaterialTheme.colorScheme.onErrorContainer)
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text(l.t("Cảnh báo thời tiết", "Weather alerts"), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                                        alerts.forEach { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer) }
                                    }
                                }
                            }
                        }
                    }
                    val tips = Insights.tips(b, s, l)
                    if (tips.isNotEmpty()) {
                        item {
                            Appear(2) {
                                Card28(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(l.t("Gợi ý hôm nay", "Today's tips"), style = MaterialTheme.typography.titleMedium)
                                        tips.forEach {
                                            Row(verticalAlignment = Alignment.Top) {
                                                Icon(Icons.Rounded.Check, null, Modifier.size(20.dp).padding(top = 2.dp), tint = MaterialTheme.colorScheme.primary)
                                                Spacer(Modifier.width(10.dp))
                                                Text(it, style = MaterialTheme.typography.bodyMedium)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    item { SectionTitle(l.t("Theo giờ", "Hourly")) }
                    item {
                        Appear(3) {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(b.hourly.take(24)) { h ->
                                    Column(
                                        Modifier
                                            .width(72.dp)
                                            .clip(MaterialTheme.shapes.extraLarge)
                                            .background(MaterialTheme.colorScheme.surfaceContainer)
                                            .padding(vertical = 14.dp, horizontal = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(Fmt.hourLabel(h.time, s, l), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        WeatherGlyph(skyOf(h.code), h.isDay, false, Modifier.size(34.dp))
                                        Text(Fmt.temp(h.tempC, s), style = MaterialTheme.typography.titleMedium)
                                        Text("${h.rainChance}%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                    item { SectionTitle(l.t("Dự báo ${b.daily.size} ngày", "${b.daily.size}-day forecast")) }
                    item { Appear(4) { DailyCard(b, s, l) } }
                    item { SectionTitle(l.t("Chỉ số thời tiết", "Weather details")) }

                    val visible = s.orderedCards().filter { it !in s.hiddenCards }
                    val rows = mutableListOf<List<String>>()
                    var pending: String? = null
                    for (k in visible) {
                        if (k == "sun") {
                            pending?.let { rows.add(listOf(it)) }
                            pending = null
                            rows.add(listOf(k))
                        } else {
                            val p = pending
                            if (p == null) pending = k else { rows.add(listOf(p, k)); pending = null }
                        }
                    }
                    pending?.let { rows.add(listOf(it)) }
                    items(rows) { r ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            r.forEach { MetricCard(it, b, s, l, Modifier.weight(1f)) }
                            if (r.size == 1 && r[0] != "sun") Spacer(Modifier.weight(1f))
                        }
                    }
                    item {
                        Text(
                            l.t("Nguồn: ", "Source: ") + (if (b.source == "google") "Google Weather API" else "Open-Meteo.com (CC BY 4.0)"),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HeaderCard(b: WeatherBundle, s: AppSettings, l: L, place: Place, animate: Boolean, motion: String) {
    val c = b.current
    val sky = skyOf(c.code)
    val ink = MaterialTheme.colorScheme.onPrimaryContainer
    val updated = remember(b.fetchedAt, s.hour24, l.lang) {
        val iso = LocalDateTime.ofInstant(Instant.ofEpochMilli(b.fetchedAt), ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"))
        Fmt.clock(iso, s, l)
    }
    val today = b.daily.firstOrNull()
    Box(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.extraLarge)
            .background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.tertiaryContainer)))
    ) {
        if (s.weatherBg) WeatherBackdrop(sky, c.isDay, animate, Modifier.matchParentSize())
        Column(Modifier.padding(22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(place.name, style = MaterialTheme.typography.titleLarge, color = ink)
                    Text(
                        l.t("Cập nhật lúc ", "Updated at ") + updated,
                        style = MaterialTheme.typography.labelMedium,
                        color = ink.copy(alpha = 0.8f)
                    )
                }
                Box(
                    Modifier
                        .size(96.dp)
                        .clip(iconShape(s.iconShape))
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.35f)),
                    contentAlignment = Alignment.Center
                ) {
                    WeatherGlyph(sky, c.isDay, animate, Modifier.size(68.dp))
                }
            }
            AnimatedContent(
                targetState = Fmt.temp(c.tempC, s),
                transitionSpec = {
                    if (motion == "off") fadeIn() togetherWith fadeOut()
                    else (slideInVertically(spring(stiffness = Spring.StiffnessMediumLow)) { it / 3 } + fadeIn()) togetherWith
                        (slideOutVertically { -it / 3 } + fadeOut())
                },
                label = "temp"
            ) { t ->
                Text(
                    t,
                    style = MaterialTheme.typography.displayLarge.copy(fontSize = 96.sp, lineHeight = 108.sp, fontWeight = FontWeight.Light),
                    color = ink
                )
            }
            Text(describe(c.code, l), style = MaterialTheme.typography.titleLarge, color = ink)
            Spacer(Modifier.height(4.dp))
            Text(
                buildString {
                    if (today != null) append(l.t("Cao ", "H ")).append(Fmt.temp(today.maxC, s)).append(l.t(" · Thấp ", " · L ")).append(Fmt.temp(today.minC, s)).append("  ·  ")
                    append(l.t("Cảm giác như ", "Feels like ")).append(Fmt.temp(c.feelsC, s))
                },
                style = MaterialTheme.typography.bodyLarge,
                color = ink
            )
        }
    }
}

@Composable
private fun DailyCard(b: WeatherBundle, s: AppSettings, l: L) {
    val days = b.daily
    if (days.isEmpty()) return
    val gMin = days.minOf { it.minC }
    val gMax = days.maxOf { it.maxC }
    val span = (gMax - gMin).coerceAtLeast(1.0)
    val track = MaterialTheme.colorScheme.surfaceVariant
    val c1 = MaterialTheme.colorScheme.tertiary
    val c2 = MaterialTheme.colorScheme.primary
    Card28(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            days.forEachIndexed { i, d ->
                Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.width(62.dp)) {
                        Text(Fmt.dayName(d.date, i, l), style = MaterialTheme.typography.bodyMedium)
                        Text(Fmt.dayShort(d.date), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    WeatherGlyph(skyOf(d.code), true, false, Modifier.size(30.dp))
                    Text(
                        d.rainChance?.let { "$it%" } ?: "",
                        Modifier.width(44.dp).padding(start = 6.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(Fmt.temp(d.minC, s), Modifier.width(34.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val start = ((d.minC - gMin) / span).toFloat()
                    val end = ((d.maxC - gMin) / span).toFloat()
                    Canvas(Modifier.weight(1f).padding(horizontal = 8.dp).height(8.dp)) {
                        val r = CornerRadius(size.height / 2)
                        drawRoundRect(track, cornerRadius = r)
                        val x0 = size.width * start
                        val x1 = (size.width * end).coerceAtLeast(x0 + size.height)
                        drawRoundRect(
                            Brush.horizontalGradient(listOf(c1, c2), startX = x0, endX = x1),
                            topLeft = Offset(x0, 0f),
                            size = Size(x1 - x0, size.height),
                            cornerRadius = r
                        )
                    }
                    Text(Fmt.temp(d.maxC, s), Modifier.width(34.dp))
                }
            }
        }
    }
}

@Composable
private fun MetricCard(key: String, b: WeatherBundle, s: AppSettings, l: L, modifier: Modifier) {
    val c = b.current
    val today = b.daily.firstOrNull()
    when (key) {
        "aqi" -> {
            val a = b.air
            MetricBox(Icons.Rounded.Air, l.t("Chất lượng không khí", "Air quality"), a?.usAqi?.toString() ?: "--",
                a?.let { aqiLabel(it.usAqi, l) + (it.pm25?.let { p -> " · PM2.5 ${p.toInt()}" } ?: "") } ?: l.t("Không có dữ liệu", "No data"), modifier)
        }
        "wind" -> MetricBox(Icons.Rounded.Speed, l.t("Gió", "Wind"), Fmt.wind(c.windKmh, s), compass(c.windDir, l) + " · ${c.windDir}°", modifier) {
            WindCompass(c.windDir)
        }
        "humidity" -> MetricBox(Icons.Rounded.WaterDrop, l.t("Độ ẩm", "Humidity"), "${c.humidity}%", l.t("Mây che phủ ", "Cloud cover ") + (c.cloud?.let { "$it%" } ?: "--"), modifier)
        "pressure" -> MetricBox(Icons.Rounded.Compress, l.t("Áp suất", "Pressure"), Fmt.pressure(c.pressure, s), l.t("Mực nước biển", "Sea level"), modifier)
        "visibility" -> MetricBox(Icons.Rounded.Visibility, l.t("Tầm nhìn", "Visibility"), c.visibilityKm?.let { Fmt.vis(it, s) } ?: "--", "", modifier)
        "uv" -> {
            val uv = maxOf(c.uv ?: 0.0, 0.0)
            val uvMax = today?.uvMax
            MetricBox(Icons.Rounded.LightMode, l.t("Chỉ số UV", "UV index"), if (c.uv == null && uvMax == null) "--" else uv.toInt().toString(),
                (if (c.uv != null) uvLabel(uv, l) else "") + (uvMax?.let { l.t(" · Cao nhất ${it.toInt()}", " · Max ${it.toInt()}") } ?: ""), modifier)
        }
        "rain" -> MetricBox(Icons.Rounded.WaterDrop, l.t("Khả năng mưa", "Rain chance"), "${today?.rainChance ?: c.rainChance ?: 0}%",
            today?.rainMm?.let { l.t("Lượng mưa ", "Amount ") + Fmt.rain(it, s) } ?: "", modifier)
        "sun" -> SunCard(today, c.time, s, l, modifier)
    }
}

@Composable
private fun MetricBox(
    icon: ImageVector,
    title: String,
    value: String,
    sub: String,
    modifier: Modifier,
    trailing: (@Composable () -> Unit)? = null
) {
    Card28(modifier) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(6.dp))
                Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(value, style = MaterialTheme.typography.headlineSmall)
                    if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                trailing?.invoke()
            }
        }
    }
}

@Composable
private fun WindCompass(deg: Int) {
    val angle by animateFloatAsState(deg.toFloat(), spring(dampingRatio = 0.7f, stiffness = 200f), label = "wind")
    val ring = MaterialTheme.colorScheme.outlineVariant
    val arrow = MaterialTheme.colorScheme.primary
    Canvas(Modifier.size(52.dp)) {
        val r = size.minDimension / 2
        val ctr = Offset(r, r)
        drawCircle(ring, r - 2f, ctr, style = Stroke(3f))
        rotate(angle + 180f, ctr) {
            val p = Path().apply {
                moveTo(r, r * 0.25f); lineTo(r * 1.3f, r * 1.3f); lineTo(r, r * 1.08f); lineTo(r * 0.7f, r * 1.3f); close()
            }
            drawPath(p, arrow)
        }
    }
}

@Composable
private fun SunCard(day: DayW?, nowLocal: String, s: AppSettings, l: L, modifier: Modifier) {
    val rise = day?.sunrise
    val set = day?.sunset
    val frac = remember(rise, set, nowLocal) {
        runCatching {
            val a = LocalDateTime.parse(rise!!)
            val z = LocalDateTime.parse(set!!)
            val n = LocalDateTime.parse(nowLocal)
            val total = java.time.Duration.between(a, z).seconds.toFloat()
            (java.time.Duration.between(a, n).seconds / total).coerceIn(0f, 1f)
        }.getOrDefault(0.5f)
    }
    val track = MaterialTheme.colorScheme.outlineVariant
    val active = MaterialTheme.colorScheme.tertiary
    Card28(modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.WbSunny, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(6.dp))
                Text(l.t("Mặt trời mọc / lặn", "Sunrise / sunset"), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Canvas(Modifier.fillMaxWidth().height(110.dp).padding(top = 8.dp, start = 24.dp, end = 24.dp)) {
                val r = minOf(size.width / 2, size.height - 12f)
                val cx = size.width / 2
                val cy = size.height - 4f
                drawArc(track, 180f, 180f, false, Offset(cx - r, cy - r), Size(2 * r, 2 * r), style = Stroke(6f, cap = StrokeCap.Round))
                drawArc(active, 180f, 180f * frac, false, Offset(cx - r, cy - r), Size(2 * r, 2 * r), style = Stroke(6f, cap = StrokeCap.Round))
                val a = (PI + PI * frac).toFloat()
                drawCircle(active, 11f, Offset(cx + r * cos(a), cy + r * sin(a)))
            }
            Row(Modifier.fillMaxWidth()) {
                Text("↑ " + Fmt.clock(rise, s, l), Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                Text("↓ " + Fmt.clock(set, s, l), style = MaterialTheme.typography.titleSmall)
            }
        }
    }
}
