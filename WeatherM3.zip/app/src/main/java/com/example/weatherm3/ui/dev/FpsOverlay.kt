package com.example.weatherm3.ui.dev

import android.view.Choreographer
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.offset
import kotlin.math.roundToInt

private data class FpsStats(val fps: Int = 0, val avgMs: Float = 0f, val p95Ms: Float = 0f, val dropped: Int = 0, val total: Int = 0, val budgetMs: Float = 16.6f)

/**
 * Lớp phủ FPS dành cho nhà phát triển (Choreographer.FrameCallback), kéo thả được.
 * "Rớt khung" = khoảng cách giữa 2 frame > 1.5 × chu kỳ làm tươi của màn hình.
 * Màu: xanh khi P95 ≤ chu kỳ, vàng khi ≤ 1.5×, đỏ khi cao hơn.
 * Lưu ý: đây là số đo thô trên luồng UI, KHÔNG thay thế gfxinfo / Macrobenchmark.
 */
@Composable
fun FpsOverlay() {
    val view = LocalView.current
    var stats by remember { mutableStateOf(FpsStats()) }
    var offset by remember { mutableStateOf(Offset(24f, 24f)) }

    DisposableEffect(view) {
        val rate = (view.display?.refreshRate ?: 60f).coerceAtLeast(30f)
        val budgetNs = (1_000_000_000.0 / rate).toLong()
        val window = LongArray(120)
        var n = 0
        var last = 0L
        var lastReport = 0L
        var dropped = 0
        var total = 0
        val ch = Choreographer.getInstance()
        val cb = object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                if (last != 0L) {
                    val d = frameTimeNanos - last
                    window[n % window.size] = d
                    n++
                    total++
                    if (d > budgetNs * 3 / 2) dropped++
                }
                last = frameTimeNanos
                if (frameTimeNanos - lastReport > 500_000_000L && n > 5) {
                    lastReport = frameTimeNanos
                    val cnt = minOf(n, window.size)
                    val arr = window.copyOf(cnt).also { it.sort() }
                    val avg = arr.average().toFloat()
                    val p95 = arr[((cnt - 1) * 0.95f).toInt()].toFloat()
                    stats = FpsStats(
                        fps = (1_000_000_000f / avg).roundToInt(),
                        avgMs = avg / 1e6f,
                        p95Ms = p95 / 1e6f,
                        dropped = dropped,
                        total = total,
                        budgetMs = budgetNs / 1e6f
                    )
                }
                ch.postFrameCallback(this)
            }
        }
        ch.postFrameCallback(cb)
        onDispose { ch.removeFrameCallback(cb) }
    }

    val color = when {
        stats.p95Ms <= stats.budgetMs * 1.05f -> Color(0xFF2E7D32)
        stats.p95Ms <= stats.budgetMs * 1.5f -> Color(0xFFF9A825)
        else -> Color(0xFFC62828)
    }
    Box(
        Modifier
            .statusBarsPadding()
            .offset { IntOffset(offset.x.roundToInt(), offset.y.roundToInt()) }
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.88f))
            .pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    offset += drag
                }
            }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            "${stats.fps} FPS\navg %.1f ms · p95 %.1f ms\nrớt %d/%d".format(stats.avgMs, stats.p95Ms, stats.dropped, stats.total),
            color = Color.White,
            style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 14.sp)
        )
    }
}
